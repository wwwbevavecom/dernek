<?php
class Auth {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }

    public function login($username, $password) {
        try {
            $stmt = $this->pdo->prepare("SELECT * FROM users WHERE username = ? AND status = 'active'");
            $stmt->execute([$username]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['user_role'] = $user['role_id'];
                $_SESSION['full_name'] = $user['full_name'];
                $_SESSION['last_activity'] = time();
                $_SESSION['user_ip'] = $_SERVER['REMOTE_ADDR'];
                $_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];

                return ['success' => true, 'message' => 'Giriş başarılı!'];
            } else {
                return ['success' => false, 'message' => 'Kullanıcı adı veya şifre hatalı!'];
            }
        } catch (Exception $e) {
            return ['success' => false, 'message' => 'Giriş işlemi sırasında hata oluştu.'];
        }
    }

    public function isLoggedIn() {
        if (!isset($_SESSION['user_id'], $_SESSION['user_ip'], $_SESSION['user_agent'])) {
            return false;
        }

        // Session hijacking koruması
        if ($_SESSION['user_ip'] !== $_SERVER['REMOTE_ADDR'] || 
            $_SESSION['user_agent'] !== $_SERVER['HTTP_USER_AGENT']) {
            $this->logout();
            return false;
        }

        // Session timeout (30 dakika)
        if (time() - $_SESSION['last_activity'] > 1800) {
            $this->logout();
            return false;
        }

        $_SESSION['last_activity'] = time();
        return true;
    }

    public function hasPermission($permission) {
        // Basit permission kontrolü - geliştirilebilir
        return $_SESSION['user_role'] == 1; // Sadece admin
    }

    public function logout() {
        $_SESSION = [];
        session_destroy();
        setcookie(session_name(), '', time() - 3600, '/');
    }
}

// Global auth instance
$auth = new Auth($pdo);
?>