<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

// Session değişkenlerini güvenli bir şekilde al
$user_id = $_SESSION['user_id'] ?? 0;
$username = $_SESSION['username'] ?? '';
$user_role = $_SESSION['user_role'] ?? '';
$full_name = $_SESSION['full_name'] ?? 'Misafir';

// Dashboard istatistikleri - hata yönetimi ile
try {
    $stats = [
        'total_members' => $pdo->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn() ?? 0,
        'total_donations' => $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM donations WHERE status = 'completed'")->fetchColumn() ?? 0,
        'total_events' => $pdo->query("SELECT COUNT(*) FROM events")->fetchColumn() ?? 0,
        'unread_messages' => $pdo->query("SELECT COUNT(*) FROM messages WHERE status = 'unread'")->fetchColumn() ?? 0,
        'unpaid_dues' => $pdo->query("SELECT COUNT(*) FROM dues WHERE status = 'unpaid'")->fetchColumn() ?? 0,
        'active_projects' => $pdo->query("SELECT COUNT(*) FROM projects WHERE status = 'ongoing'")->fetchColumn() ?? 0
    ];

    // Son aktiviteler
    $recent_activities = $pdo->query("
        (SELECT 'yeni_uye' as type, full_name as title, created_at FROM members ORDER BY created_at DESC LIMIT 3)
        UNION ALL
        (SELECT 'bagis' as type, CONCAT(donor_name, ' - ', amount, ' TL') as title, created_at FROM donations ORDER BY created_at DESC LIMIT 3)
        UNION ALL
        (SELECT 'etkinlik' as type, title, created_at FROM events ORDER BY created_at DESC LIMIT 3)
        ORDER BY created_at DESC LIMIT 5
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    // Hata durumunda varsayılan değerler
    $stats = [
        'total_members' => 0,
        'total_donations' => 0,
        'total_events' => 0,
        'unread_messages' => 0,
        'unpaid_dues' => 0,
        'active_projects' => 0
    ];
    $recent_activities = [];
    $error = "İstatistikler yüklenirken hata oluştu: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - <?php echo getSetting('site_title'); ?></title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --sidebar-width: 250px;
            --header-height: 60px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            overflow-y: auto;
            transition: all 0.3s;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 20px;
            background: rgba(0, 0, 0, 0.2);
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5rem;
            margin-bottom: 5px;
        }

        .sidebar-menu {
            padding: 15px 0;
        }

        .sidebar-menu ul {
            list-style: none;
        }

        .sidebar-menu li {
            position: relative;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(0, 0, 0, 0.2);
            color: white;
            border-left: 3px solid var(--secondary-color);
        }

        .sidebar-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .submenu {
            display: none;
            background: rgba(0, 0, 0, 0.1);
        }

        .submenu a {
            padding-left: 50px;
        }

        .has-submenu > a::after {
            content: '\f107';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-left: auto;
            transition: transform 0.3s;
        }

        .has-submenu.active > a::after {
            transform: rotate(180deg);
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: all 0.3s;
        }

        .header {
            height: var(--header-height);
            background: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-left h1 {
            font-size: 1.5rem;
            color: var(--primary-color);
        }

        .header-right {
            display: flex;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
            margin-right: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--secondary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            margin-right: 10px;
        }

        .logout-btn {
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .logout-btn i {
            margin-right: 5px;
        }

        .content {
            padding: 20px;
        }

        .dashboard-cards {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            transition: transform 0.3s;
        }

        .card:hover {
            transform: translateY(-5px);
        }

        .card-header {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }

        .card-icon {
            width: 50px;
            height: 50px;
            border-radius: 50%;
            background: var(--secondary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 1.5rem;
            margin-right: 15px;
        }

        .card-body h3 {
            font-size: 1.8rem;
            margin-bottom: 5px;
        }

        .card-body p {
            color: #777;
        }

        .recent-activities {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
        }

        .section-title {
            font-size: 1.3rem;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
            color: var(--primary-color);
        }

        .activity-list {
            list-style: none;
        }

        .activity-item {
            display: flex;
            padding: 10px 0;
            border-bottom: 1px solid #f5f5f5;
        }

        .activity-icon {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: #f8f9fa;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 15px;
            color: var(--secondary-color);
        }

        .activity-content {
            flex: 1;
        }

        .activity-time {
            color: #777;
            font-size: 0.85rem;
        }

        /* Toggle Button for Mobile */
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--primary-color);
            cursor: pointer;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .toggle-sidebar {
                display: block;
            }
            
            .header-left h1 {
                font-size: 1.2rem;
            }
        }

        @media (max-width: 576px) {
            .dashboard-cards {
                grid-template-columns: 1fr;
            }
            
            .user-info span {
                display: none;
            }
        }

        .alert {
            padding: 10px;
            background: #f8d7da;
            color: #721c24;
            border-radius: 5px;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>DERNEK PORTALI</h2>
            <p>YÖNETİM PANELİ</p>
        </div>
        
        <nav class="sidebar-menu">
            <ul>
                <li><a href="index.php" class="active"><i class="fas fa-home"></i> Anasayfa</a></li>
                
                <li class="has-submenu">
                    <a href="#"><i class="fas fa-cogs"></i> Site Yönetimi</a>
                    <ul class="submenu">
                        <li><a href="settings.php">Genel Ayarlar</a></li>
                        <li><a href="president_settings.php">Başkan Ayarlar</a></li>
                        <li><a href="popup_message.php">Açılır Mesaj</a></li>
                        <li><a href="api_settings.php">Api Ayarları</a></li>
                        <li><a href="contact_settings.php">İletişim Ayarları</a></li>
                        <li><a href="social_media.php">Sosyal Medya Ayarları</a></li>
                        <li><a href="module_settings.php">Modül Ayarları</a></li>
                        <li><a href="limit_settings.php">Limit Ayarları</a></li>
                        <li><a href="maintenance.php">Site Bakım Modu</a></li>
                        <li><a href="mail_settings.php">Mail Ayarları</a></li>
                        <li><a href="sms_settings.php">SMS Ayarları</a></li>
                        <li><a href="payment_gateways.php">Sanal Poslar</a></li>
                        <li><a href="backgrounds.php">Arka Plan Görselleri</a></li>
                    </ul>
                </li>
                
                <li class="has-submenu">
                    <a href="language_management.php"><i class="fas fa-language"></i> Dil Yönetimi</a>
                </li>
                
                <li class="has-submenu">
                    <a href="menu_management.php"><i class="fas fa-bars"></i> Menü Yönetimi</a>
                </li>
                
                <li class="has-submenu">
                    <a href="member_management.php"><i class="fas fa-users"></i> Üye Yönetimi</a>
                </li>
                
                <li class="has-submenu">
                    <a href="#"><i class="fas fa-file-alt"></i> İçerik Yönetimi</a>
                    <ul class="submenu">
                        <li><a href="donation_management.php">Bağış Yönetimi</a></li>
                        <li><a href="dues_management.php">Aidat Yönetimi</a></li>
                        <li><a href="project_management.php">Proje Yönetimi</a></li>
                        <li><a href="page_management.php">Sayfa Yönetimi</a></li>
                        <li><a href="service_management.php">Hizmet Yönetimi</a></li>
                        <li><a href="profile_management.php">Profil Yönetimi</a></li>
                        <li><a href="event_management.php">Etkinlik Yönetimi</a></li>
                        <li><a href="association_decisions.php">Dernek Kararları</a></li>
                        <li><a href="activity_reports.php">Faaliyet Raporları</a></li>
                        <li><a href="scholarship_management.php">Burs Başvuru Yönetimi</a></li>
                        <li><a href="ad_management.php">İlan Yönetimi</a></li>
                        <li><a href="announcement_management.php">Duyuru Yönetimi</a></li>
                        <li><a href="news_management.php">Haber Yönetimi</a></li>
                    </ul>
                </li>
                
                <li class="has-submenu">
                    <a href="#"><i class="fas fa-images"></i> Medya Yönetimi</a>
                    <ul class="submenu">
                        <li><a href="slider_management.php">Slider Yönetimi</a></li>
                        <li><a href="photo_gallery.php">Foto Galeri</a></li>
                        <li><a href="video_gallery.php">Video Galeri</a></li>
                    </ul>
                </li>
                
                <li class="has-submenu">
                    <a href="manager_management.php"><i class="fas fa-user-tie"></i> Dernek Yöneticiler</a>
                </li>
                
                <li class="has-submenu">
                    <a href="notifications.php"><i class="fas fa-bell"></i> Bildirimler</a>
                </li>
                
                <li class="has-submenu">
                    <a href="messages.php"><i class="fas fa-envelope"></i> Mesajlar</a>
                </li>
                
                <li class="has-submenu">
                    <a href="notes.php"><i class="fas fa-sticky-note"></i> Not Defteri</a>
                </li>
                
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Oturumu Kapat</a></li>
            </ul>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
                <h1>Anasayfa</h1>
            </div>
            
            <div class="header-right">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php 
                        // Güvenli avatar oluşturma
                        $initials = 'AD';
                        if (!empty($full_name) && $full_name != 'Misafir') {
                            $name_parts = explode(' ', $full_name);
                            $initials = '';
                            foreach ($name_parts as $part) {
                                $initials .= strtoupper(substr($part, 0, 1));
                                if (strlen($initials) >= 2) break;
                            }
                        }
                        echo $initials;
                        ?>
                    </div>
                    <span><?php echo htmlspecialchars($full_name); ?></span>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Çıkış
                </a>
            </div>
        </header>
        
        <!-- Content -->
        <div class="content">
            <?php if (isset($error)): ?>
                <div class="alert"><?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="dashboard-cards">
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="card-body">
                            <h3><?php echo $stats['total_members']; ?></h3>
                            <p>Toplam Üye</p>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-hand-holding-usd"></i>
                        </div>
                        <div class="card-body">
                            <h3><?php echo number_format(floatval($stats['total_donations']), 2); ?> TL</h3>
                            <p>Toplam Bağış</p>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-calendar-alt"></i>
                        </div>
                        <div class="card-body">
                            <h3><?php echo $stats['total_events']; ?></h3>
                            <p>Toplam Etkinlik</p>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="card-body">
                            <h3><?php echo $stats['unread_messages']; ?></h3>
                            <p>Okunmamış Mesaj</p>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-money-bill-wave"></i>
                        </div>
                        <div class="card-body">
                            <h3><?php echo $stats['unpaid_dues']; ?></h3>
                            <p>Ödenmemiş Aidat</p>
                        </div>
                    </div>
                </div>
                
                <div class="card">
                    <div class="card-header">
                        <div class="card-icon">
                            <i class="fas fa-project-diagram"></i>
                        </div>
                        <div class="card-body">
                            <h3><?php echo $stats['active_projects']; ?></h3>
                            <p>Aktif Proje</p>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="recent-activities">
                <h2 class="section-title">Son Aktiviteler</h2>
                <ul class="activity-list">
                    <?php if (!empty($recent_activities)): ?>
                        <?php foreach($recent_activities as $activity): ?>
                        <li class="activity-item">
                            <div class="activity-icon">
                                <?php 
                                $icon = 'fas fa-user-plus';
                                if ($activity['type'] == 'bagis') $icon = 'fas fa-donate';
                                if ($activity['type'] == 'etkinlik') $icon = 'fas fa-calendar-check';
                                ?>
                                <i class="<?php echo $icon; ?>"></i>
                            </div>
                            <div class="activity-content">
                                <p><?php echo htmlspecialchars($activity['title']); ?></p>
                                <span class="activity-time">
                                    <?php echo date('d.m.Y H:i', strtotime($activity['created_at'])); ?>
                                </span>
                            </div>
                        </li>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <li class="activity-item">
                            <div class="activity-content">
                                <p>Henüz aktivite bulunmamaktadır.</p>
                            </div>
                        </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>

    <script>
        // Toggle sidebar on mobile
        document.querySelector('.toggle-sidebar').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
        
        // Toggle submenus
        const hasSubmenu = document.querySelectorAll('.has-submenu > a');
        
        hasSubmenu.forEach(item => {
            item.addEventListener('click', function(e) {
                if (window.innerWidth > 992) {
                    e.preventDefault();
                    const parent = this.parentElement;
                    parent.classList.toggle('active');
                    
                    const submenu = parent.querySelector('.submenu');
                    if (submenu.style.display === 'block') {
                        submenu.style.display = 'none';
                    } else {
                        submenu.style.display = 'block';
                    }
                }
            });
        });
        
        // Close sidebar on mobile when clicking a menu item
        const menuItems = document.querySelectorAll('.sidebar-menu a');
        menuItems.forEach(item => {
            item.addEventListener('click', function() {
                if (window.innerWidth <= 992) {
                    document.querySelector('.sidebar').classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>