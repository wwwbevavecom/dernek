<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$success = '';
$error = '';

// Bağış listeleme
$donations = [];
try {
    $stmt = $pdo->query("SELECT * FROM donations ORDER BY created_at DESC");
    $donations = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Bağışlar yüklenirken hata oluştu: " . $e->getMessage();
}

// Bağış ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_donation'])) {
    try {
        $donor_name = sanitize($_POST['donor_name']);
        $amount = floatval($_POST['amount']);
        $donation_date = $_POST['donation_date'];
        $payment_method = sanitize($_POST['payment_method']);
        $description = sanitize($_POST['description']);
        
        $stmt = $pdo->prepare("INSERT INTO donations (donor_name, amount, donation_date, payment_method, description) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$donor_name, $amount, $donation_date, $payment_method, $description])) {
            $success = "Bağış başarıyla eklendi!";
        } else {
            $error = "Bağış eklenirken hata oluştu!";
        }
    } catch(Exception $e) {
        $error = "Bağış eklenirken hata oluştu: " . $e->getMessage();
    }
}

include 'header.php';
?>

<div class="content">
    <div class="content-header">
        <h2>Bağış Yönetimi</h2>
        <button class="btn btn-primary" onclick="openModal()">
            <i class="fas fa-plus"></i> Yeni Bağış Ekle
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Bağışçı Adı</th>
                            <th>Miktar</th>
                            <th>Bağış Tarihi</th>
                            <th>Ödeme Yöntemi</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($donations as $donation): ?>
                        <tr>
                            <td><?php echo $donation['id']; ?></td>
                            <td><?php echo $donation['donor_name']; ?></td>
                            <td><?php echo number_format($donation['amount'], 2); ?> TL</td>
                            <td><?php echo date('d.m.Y', strtotime($donation['donation_date'])); ?></td>
                            <td>
                                <?php 
                                $payment_methods = [
                                    'cash' => 'Nakit',
                                    'credit_card' => 'Kredi Kartı',
                                    'bank_transfer' => 'Banka Transferi'
                                ];
                                echo $payment_methods[$donation['payment_method']] ?? $donation['payment_method'];
                                ?>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo $donation['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                    <?php echo $donation['status'] == 'completed' ? 'Tamamlandı' : 'Bekliyor'; ?>
                                </span>
                            </td>
                            <td>
                                <a href="?delete=<?php echo $donation['id']; ?>" class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Bu bağışı silmek istediğinizden emin misiniz?')">
                                    <i class="fas fa-trash"></i> Sil
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="donationModal" class="modal">
    <div class="modal-content">
        <h3>Yeni Bağış Ekle</h3>
        <form method="POST">
            <div class="form-group">
                <label>Bağışçı Adı</label>
                <input type="text" name="donor_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Miktar (TL)</label>
                <input type="number" name="amount" class="form-control" step="0.01" required>
            </div>
            <div class="form-group">
                <label>Bağış Tarihi</label>
                <input type="date" name="donation_date" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Ödeme Yöntemi</label>
                <select name="payment_method" class="form-control" required>
                    <option value="cash">Nakit</option>
                    <option value="credit_card">Kredi Kartı</option>
                    <option value="bank_transfer">Banka Transferi</option>
                </select>
            </div>
            <div class="form-group">
                <label>Açıklama</label>
                <textarea name="description" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_donation" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('donationModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('donationModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('donationModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include 'footer.php'; ?>