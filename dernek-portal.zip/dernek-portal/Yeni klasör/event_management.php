<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$success = '';
$error = '';

// Etkinlik listeleme
$events = [];
try {
    $stmt = $pdo->query("SELECT * FROM events ORDER BY event_date DESC");
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Etkinlikler yüklenirken hata oluştu: " . $e->getMessage();
}

// Etkinlik ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_event'])) {
    try {
        $title = sanitize($_POST['title']);
        $description = sanitize($_POST['description']);
        $event_date = $_POST['event_date'];
        $event_time = $_POST['event_time'];
        $location = sanitize($_POST['location']);
        $max_participants = intval($_POST['max_participants']);
        
        $stmt = $pdo->prepare("INSERT INTO events (title, description, event_date, event_time, location, max_participants) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$title, $description, $event_date, $event_time, $location, $max_participants])) {
            $success = "Etkinlik başarıyla eklendi!";
        } else {
            $error = "Etkinlik eklenirken hata oluştu!";
        }
    } catch(Exception $e) {
        $error = "Etkinlik eklenirken hata oluştu: " . $e->getMessage();
    }
}

include 'header.php';
?>

<div class="content">
    <div class="content-header">
        <h2>Etkinlik Yönetimi</h2>
        <button class="btn btn-primary" onclick="openModal()">
            <i class="fas fa-plus"></i> Yeni Etkinlik Ekle
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Etkinlik Adı</th>
                            <th>Tarih</th>
                            <th>Saat</th>
                            <th>Konum</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($events as $event): ?>
                        <tr>
                            <td><?php echo $event['id']; ?></td>
                            <td><?php echo $event['title']; ?></td>
                            <td><?php echo date('d.m.Y', strtotime($event['event_date'])); ?></td>
                            <td><?php echo $event['event_time']; ?></td>
                            <td><?php echo $event['location']; ?></td>
                            <td>
                                <?php 
                                $status_class = [
                                    'upcoming' => 'primary',
                                    'ongoing' => 'success',
                                    'completed' => 'secondary',
                                    'cancelled' => 'danger'
                                ];
                                $status_text = [
                                    'upcoming' => 'Yaklaşan',
                                    'ongoing' => 'Devam Ediyor',
                                    'completed' => 'Tamamlandı',
                                    'cancelled' => 'İptal Edildi'
                                ];
                                ?>
                                <span class="badge badge-<?php echo $status_class[$event['status']] ?? 'secondary'; ?>">
                                    <?php echo $status_text[$event['status']] ?? $event['status']; ?>
                                </span>
                            </td>
                            <td>
                                <a href="?delete=<?php echo $event['id']; ?>" class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Bu etkinliği silmek istediğinizden emin misiniz?')">
                                    <i class="fas fa-trash"></i> Sil
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="eventModal" class="modal">
    <div class="modal-content">
        <h3>Yeni Etkinlik Ekle</h3>
        <form method="POST">
            <div class="form-group">
                <label>Etkinlik Adı</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Açıklama</label>
                <textarea name="description" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Etkinlik Tarihi</label>
                <input type="date" name="event_date" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Etkinlik Saati</label>
                <input type="time" name="event_time" class="form-control">
            </div>
            <div class="form-group">
                <label>Konum</label>
                <input type="text" name="location" class="form-control">
            </div>
            <div class="form-group">
                <label>Maksimum Katılımcı</label>
                <input type="number" name="max_participants" class="form-control">
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_event" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('eventModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('eventModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('eventModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include 'footer.php'; ?>