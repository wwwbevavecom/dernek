<?php
require_once 'config.php';

if (!isLoggedIn() || !isAdmin()) {
    redirect('login.php');
}

$success = '';
$error = '';

// Ayarları getir
$settings = [];
try {
    $stmt = $pdo->query("SELECT * FROM settings");
    $settings_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($settings_data as $setting) {
        $settings[$setting['setting_key']] = $setting['setting_value'];
    }
} catch(Exception $e) {
    $error = "Ayarlar yüklenirken hata oluştu: " . $e->getMessage();
}

// Ayarları güncelle
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        foreach ($_POST as $key => $value) {
            if (strpos($key, 'setting_') === 0) {
                $setting_key = str_replace('setting_', '', $key);
                $setting_value = sanitize($value);
                
                // Var olan ayarı güncelle veya yeni ekle
                $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                                      ON DUPLICATE KEY UPDATE setting_value = ?");
                $stmt->execute([$setting_key, $setting_value, $setting_value]);
            }
        }
        $success = "Ayarlar başarıyla güncellendi!";
    } catch(Exception $e) {
        $error = "Ayarlar güncellenirken hata oluştu: " . $e->getMessage();
    }
}

include 'header.php';
?>

<div class="content">
    <div class="content-header">
        <h2>Genel Ayarlar</h2>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <form method="POST">
                <div class="form-group">
                    <label>Site Başlığı</label>
                    <input type="text" name="setting_site_title" class="form-control" 
                           value="<?php echo $settings['site_title'] ?? ''; ?>" required>
                </div>

                <div class="form-group">
                    <label>Site Açıklaması</label>
                    <textarea name="setting_site_description" class="form-control" rows="3"><?php echo $settings['site_description'] ?? ''; ?></textarea>
                </div>

                <div class="form-group">
                    <label>İletişim E-posta</label>
                    <input type="email" name="setting_contact_email" class="form-control" 
                           value="<?php echo $settings['contact_email'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label>İletişim Telefon</label>
                    <input type="text" name="setting_contact_phone" class="form-control" 
                           value="<?php echo $settings['contact_phone'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label>Site Anahtar Kelimeler</label>
                    <input type="text" name="setting_site_keywords" class="form-control" 
                           value="<?php echo $settings['site_keywords'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label>Logo URL</label>
                    <input type="text" name="setting_logo_url" class="form-control" 
                           value="<?php echo $settings['logo_url'] ?? ''; ?>">
                </div>

                <div class="form-group">
                    <label>Favicon URL</label>
                    <input type="text" name="setting_favicon_url" class="form-control" 
                           value="<?php echo $settings['favicon_url'] ?? ''; ?>">
                </div>

                <button type="submit" class="btn btn-primary">Ayarları Kaydet</button>
            </form>
        </div>
    </div>
</div>

<?php include 'footer.php'; ?>