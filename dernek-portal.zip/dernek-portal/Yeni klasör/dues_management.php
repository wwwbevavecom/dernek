<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$success = '';
$error = '';

// Aidat listeleme
$dues = [];
try {
    $stmt = $pdo->query("SELECT d.*, m.full_name FROM dues d LEFT JOIN members m ON d.member_id = m.id ORDER BY d.created_at DESC");
    $dues = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Aidatlar yüklenirken hata oluştu: " . $e->getMessage();
}

// Üyeleri getir
$members = [];
try {
    $stmt = $pdo->query("SELECT id, full_name FROM members WHERE status = 'active'");
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Üyeler yüklenirken hata oluştu: " . $e->getMessage();
}

// Aidat ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_due'])) {
    try {
        $member_id = intval($_POST['member_id']);
        $amount = floatval($_POST['amount']);
        $due_date = $_POST['due_date'];
        $description = sanitize($_POST['description']);
        
        $stmt = $pdo->prepare("INSERT INTO dues (member_id, amount, due_date, description) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$member_id, $amount, $due_date, $description])) {
            $success = "Aidat başarıyla eklendi!";
        } else {
            $error = "Aidat eklenirken hata oluştu!";
        }
    } catch(Exception $e) {
        $error = "Aidat eklenirken hata oluştu: " . $e->getMessage();
    }
}

include 'header.php';
?>

<div class="content">
    <div class="content-header">
        <h2>Aidat Yönetimi</h2>
        <button class="btn btn-primary" onclick="openModal()">
            <i class="fas fa-plus"></i> Yeni Aidat Ekle
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Üye</th>
                            <th>Miktar</th>
                            <th>Son Ödeme Tarihi</th>
                            <th>Ödeme Tarihi</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($dues as $due): ?>
                        <tr>
                            <td><?php echo $due['id']; ?></td>
                            <td><?php echo $due['full_name']; ?></td>
                            <td><?php echo number_format($due['amount'], 2); ?> TL</td>
                            <td><?php echo date('d.m.Y', strtotime($due['due_date'])); ?></td>
                            <td><?php echo $due['payment_date'] ? date('d.m.Y', strtotime($due['payment_date'])) : '-'; ?></td>
                            <td>
                                <span class="badge badge-<?php echo $due['status'] == 'paid' ? 'success' : 'danger'; ?>">
                                    <?php echo $due['status'] == 'paid' ? 'Ödendi' : 'Ödenmedi'; ?>
                                </span>
                            </td>
                            <td>
                                <?php if ($due['status'] == 'unpaid'): ?>
                                    <a href="?pay=<?php echo $due['id']; ?>" class="btn btn-success btn-sm">
                                        <i class="fas fa-check"></i> Ödendi
                                    </a>
                                <?php endif; ?>
                                <a href="?delete=<?php echo $due['id']; ?>" class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Bu aidatı silmek istediğinizden emin misiniz?')">
                                    <i class="fas fa-trash"></i> Sil
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="dueModal" class="modal">
    <div class="modal-content">
        <h3>Yeni Aidat Ekle</h3>
        <form method="POST">
            <div class="form-group">
                <label>Üye</label>
                <select name="member_id" class="form-control" required>
                    <option value="">Üye Seçin</option>
                    <?php foreach($members as $member): ?>
                        <option value="<?php echo $member['id']; ?>"><?php echo $member['full_name']; ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Miktar (TL)</label>
                <input type="number" name="amount" class="form-control" step="0.01" required>
            </div>
            <div class="form-group">
                <label>Son Ödeme Tarihi</label>
                <input type="date" name="due_date" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Açıklama</label>
                <textarea name="description" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_due" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('dueModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('dueModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('dueModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include 'footer.php'; ?>