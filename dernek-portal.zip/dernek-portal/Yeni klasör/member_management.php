<?php
require_once 'config.php';

if (!isLoggedIn()) {
    redirect('login.php');
}

$success = '';
$error = '';

// Üye listeleme
$members = [];
try {
    $stmt = $pdo->query("SELECT * FROM members ORDER BY created_at DESC");
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Üyeler yüklenirken hata oluştu: " . $e->getMessage();
}

// Üye ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_member'])) {
    try {
        $full_name = sanitize($_POST['full_name']);
        $tc_no = sanitize($_POST['tc_no']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        $address = sanitize($_POST['address']);
        $membership_date = $_POST['membership_date'];
        
        $stmt = $pdo->prepare("INSERT INTO members (full_name, tc_no, email, phone, address, membership_date) VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$full_name, $tc_no, $email, $phone, $address, $membership_date])) {
            $success = "Üye başarıyla eklendi!";
        } else {
            $error = "Üye eklenirken hata oluştu!";
        }
    } catch(Exception $e) {
        $error = "Üye eklenirken hata oluştu: " . $e->getMessage();
    }
}

// Üye silme
if (isset($_GET['delete'])) {
    try {
        $id = intval($_GET['delete']);
        $stmt = $pdo->prepare("DELETE FROM members WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "Üye başarıyla silindi!";
        } else {
            $error = "Üye silinirken hata oluştu!";
        }
    } catch(Exception $e) {
        $error = "Üye silinirken hata oluştu: " . $e->getMessage();
    }
}

include 'header.php';
?>

<div class="content">
    <div class="content-header">
        <h2>Üye Yönetimi</h2>
        <button class="btn btn-primary" onclick="openModal()">
            <i class="fas fa-plus"></i> Yeni Üye Ekle
        </button>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Ad Soyad</th>
                            <th>TC No</th>
                            <th>E-posta</th>
                            <th>Telefon</th>
                            <th>Üyelik Tarihi</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($members as $member): ?>
                        <tr>
                            <td><?php echo $member['id']; ?></td>
                            <td><?php echo $member['full_name']; ?></td>
                            <td><?php echo $member['tc_no']; ?></td>
                            <td><?php echo $member['email']; ?></td>
                            <td><?php echo $member['phone']; ?></td>
                            <td><?php echo date('d.m.Y', strtotime($member['membership_date'])); ?></td>
                            <td>
                                <span class="badge badge-<?php echo $member['status'] == 'active' ? 'success' : 'danger'; ?>">
                                    <?php echo $member['status'] == 'active' ? 'Aktif' : 'Pasif'; ?>
                                </span>
                            </td>
                            <td>
                                <a href="?delete=<?php echo $member['id']; ?>" class="btn btn-danger btn-sm" 
                                   onclick="return confirm('Bu üyeyi silmek istediğinizden emin misiniz?')">
                                    <i class="fas fa-trash"></i> Sil
                                </a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="memberModal" class="modal">
    <div class="modal-content">
        <h3>Yeni Üye Ekle</h3>
        <form method="POST">
            <div class="form-group">
                <label>Ad Soyad</label>
                <input type="text" name="full_name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>TC Kimlik No</label>
                <input type="text" name="tc_no" class="form-control" maxlength="11">
            </div>
            <div class="form-group">
                <label>E-posta</label>
                <input type="email" name="email" class="form-control">
            </div>
            <div class="form-group">
                <label>Telefon</label>
                <input type="text" name="phone" class="form-control">
            </div>
            <div class="form-group">
                <label>Adres</label>
                <textarea name="address" class="form-control" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Üyelik Tarihi</label>
                <input type="date" name="membership_date" class="form-control" required>
            </div>
            <div class="form-actions">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_member" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('memberModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('memberModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('memberModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include 'footer.php'; ?>