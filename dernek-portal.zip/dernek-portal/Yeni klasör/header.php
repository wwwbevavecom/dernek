<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo getSetting('site_title'); ?> - Yönetim Paneli</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #3498db;
            --accent-color: #e74c3c;
            --light-color: #ecf0f1;
            --dark-color: #2c3e50;
            --sidebar-width: 250px;
            --header-height: 60px;
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f7fa;
            color: #333;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: var(--sidebar-width);
            background: var(--primary-color);
            color: white;
            height: 100vh;
            position: fixed;
            overflow-y: auto;
            transition: all 0.3s;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 20px;
            background: rgba(0, 0, 0, 0.2);
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header h2 {
            font-size: 1.5rem;
            margin-bottom: 5px;
        }

        .sidebar-menu {
            padding: 15px 0;
        }

        .sidebar-menu ul {
            list-style: none;
        }

        .sidebar-menu li {
            position: relative;
        }

        .sidebar-menu a {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }

        .sidebar-menu a:hover, .sidebar-menu a.active {
            background: rgba(0, 0, 0, 0.2);
            color: white;
            border-left: 3px solid var(--secondary-color);
        }

        .sidebar-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }

        .submenu {
            display: none;
            background: rgba(0, 0, 0, 0.1);
        }

        .submenu a {
            padding-left: 50px;
        }

        .has-submenu > a::after {
            content: '\f107';
            font-family: 'Font Awesome 5 Free';
            font-weight: 900;
            margin-left: auto;
            transition: transform 0.3s;
        }

        .has-submenu.active > a::after {
            transform: rotate(180deg);
        }

        /* Main Content Styles */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: all 0.3s;
        }

        .header {
            height: var(--header-height);
            background: white;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 0 20px;
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-left h1 {
            font-size: 1.5rem;
            color: var(--primary-color);
        }

        .header-right {
            display: flex;
            align-items: center;
        }

        .user-info {
            display: flex;
            align-items: center;
            margin-right: 15px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--secondary-color);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
            margin-right: 10px;
        }

        .logout-btn {
            background: var(--accent-color);
            color: white;
            border: none;
            padding: 8px 15px;
            border-radius: 4px;
            cursor: pointer;
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .logout-btn i {
            margin-right: 5px;
        }

        .content {
            padding: 20px;
        }

        .content-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .card {
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .card-body {
            padding: 20px;
        }

        .btn {
            padding: 10px 15px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            display: inline-flex;
            align-items: center;
            font-size: 14px;
        }

        .btn-primary {
            background: var(--secondary-color);
            color: white;
        }

        .btn-danger {
            background: var(--accent-color);
            color: white;
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-sm {
            padding: 5px 10px;
            font-size: 12px;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-control {
            width: 100%;
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
        }

        .form-control:focus {
            border-color: var(--secondary-color);
            outline: none;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
        }

        .table th, .table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #eee;
        }

        .table th {
            background: #f8f9fa;
            font-weight: 600;
        }

        .table-striped tbody tr:nth-of-type(odd) {
            background-color: #f8f9fa;
        }

        .table-responsive {
            overflow-x: auto;
        }

        .badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 12px;
            font-weight: 500;
        }

        .badge-success { background: #d4edda; color: #155724; }
        .badge-danger { background: #f8d7da; color: #721c24; }
        .badge-warning { background: #fff3cd; color: #856404; }
        .badge-primary { background: #cce5ff; color: #004085; }
        .badge-secondary { background: #e2e3e5; color: #383d41; }

        .alert {
            padding: 12px 15px;
            border-radius: 5px;
            margin-bottom: 20px;
        }

        .alert-success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }

        .alert-danger {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }

        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background: rgba(0,0,0,0.5);
        }

        .modal-content {
            background: white;
            margin: 5% auto;
            padding: 20px;
            border-radius: 8px;
            width: 90%;
            max-width: 500px;
            max-height: 80vh;
            overflow-y: auto;
        }

        .form-actions {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
            margin-top: 20px;
        }

        /* Toggle Button for Mobile */
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.5rem;
            color: var(--primary-color);
            cursor: pointer;
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .toggle-sidebar {
                display: block;
            }
            
            .header-left h1 {
                font-size: 1.2rem;
            }
        }

        @media (max-width: 576px) {
            .content-header {
                flex-direction: column;
                gap: 10px;
                align-items: flex-start;
            }
            
            .user-info span {
                display: none;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <h2>DERNEK PORTALI</h2>
            <p>YÖNETİM PANELİ</p>
        </div>
        
        <nav class="sidebar-menu">
            <ul>
                <li><a href="index.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'index.php' ? 'active' : ''; ?>"><i class="fas fa-home"></i> Anasayfa</a></li>
                
                <li class="has-submenu">
                    <a href="#"><i class="fas fa-cogs"></i> Site Yönetimi</a>
                    <ul class="submenu">
                        <li><a href="settings.php">Genel Ayarlar</a></li>
                        <li><a href="president_settings.php">Başkan Ayarlar</a></li>
                        <li><a href="popup_message.php">Açılır Mesaj</a></li>
                        <li><a href="api_settings.php">Api Ayarları</a></li>
                        <li><a href="contact_settings.php">İletişim Ayarları</a></li>
                        <li><a href="social_media.php">Sosyal Medya Ayarları</a></li>
                        <li><a href="module_settings.php">Modül Ayarları</a></li>
                        <li><a href="limit_settings.php">Limit Ayarları</a></li>
                        <li><a href="maintenance.php">Site Bakım Modu</a></li>
                        <li><a href="mail_settings.php">Mail Ayarları</a></li>
                        <li><a href="sms_settings.php">SMS Ayarları</a></li>
                        <li><a href="payment_gateways.php">Sanal Poslar</a></li>
                        <li><a href="backgrounds.php">Arka Plan Görselleri</a></li>
                    </ul>
                </li>
                
                <li><a href="language_management.php"><i class="fas fa-language"></i> Dil Yönetimi</a></li>
                <li><a href="menu_management.php"><i class="fas fa-bars"></i> Menü Yönetimi</a></li>
                <li><a href="member_management.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'member_management.php' ? 'active' : ''; ?>"><i class="fas fa-users"></i> Üye Yönetimi</a></li>
                
                <li class="has-submenu">
                    <a href="#"><i class="fas fa-file-alt"></i> İçerik Yönetimi</a>
                    <ul class="submenu">
                        <li><a href="donation_management.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'donation_management.php' ? 'active' : ''; ?>">Bağış Yönetimi</a></li>
                        <li><a href="dues_management.php">Aidat Yönetimi</a></li>
                        <li><a href="project_management.php">Proje Yönetimi</a></li>
                        <li><a href="page_management.php">Sayfa Yönetimi</a></li>
                        <li><a href="service_management.php">Hizmet Yönetimi</a></li>
                        <li><a href="profile_management.php">Profil Yönetimi</a></li>
                        <li><a href="event_management.php" class="<?php echo basename($_SERVER['PHP_SELF']) == 'event_management.php' ? 'active' : ''; ?>">Etkinlik Yönetimi</a></li>
                        <li><a href="association_decisions.php">Dernek Kararları</a></li>
                        <li><a href="activity_reports.php">Faaliyet Raporları</a></li>
                        <li><a href="scholarship_management.php">Burs Başvuru Yönetimi</a></li>
                        <li><a href="ad_management.php">İlan Yönetimi</a></li>
                        <li><a href="announcement_management.php">Duyuru Yönetimi</a></li>
                        <li><a href="news_management.php">Haber Yönetimi</a></li>
                    </ul>
                </li>
                
                <li class="has-submenu">
                    <a href="#"><i class="fas fa-images"></i> Medya Yönetimi</a>
                    <ul class="submenu">
                        <li><a href="slider_management.php">Slider Yönetimi</a></li>
                        <li><a href="photo_gallery.php">Foto Galeri</a></li>
                        <li><a href="video_gallery.php">Video Galeri</a></li>
                    </ul>
                </li>
                
                <li><a href="manager_management.php"><i class="fas fa-user-tie"></i> Dernek Yöneticiler</a></li>
                <li><a href="notifications.php"><i class="fas fa-bell"></i> Bildirimler</a></li>
                <li><a href="messages.php"><i class="fas fa-envelope"></i> Mesajlar</a></li>
                <li><a href="notes.php"><i class="fas fa-sticky-note"></i> Not Defteri</a></li>
                <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Oturumu Kapat</a></li>
            </ul>
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <!-- Header -->
        <header class="header">
            <div class="header-left">
                <button class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
                <h1><?php echo $page_title ?? 'Yönetim Paneli'; ?></h1>
            </div>
            
            <div class="header-right">
                <div class="user-info">
                    <div class="user-avatar">
                        <?php 
                        $initials = 'AD';
                        if (!empty($_SESSION['full_name']) && $_SESSION['full_name'] != 'Misafir') {
                            $name_parts = explode(' ', $_SESSION['full_name']);
                            $initials = '';
                            foreach ($name_parts as $part) {
                                $initials .= strtoupper(substr($part, 0, 1));
                                if (strlen($initials) >= 2) break;
                            }
                        }
                        echo $initials;
                        ?>
                    </div>
                    <span><?php echo $_SESSION['full_name'] ?? 'Misafir'; ?></span>
                </div>
                <a href="logout.php" class="logout-btn">
                    <i class="fas fa-sign-out-alt"></i> Çıkış
                </a>
            </div>
        </header>