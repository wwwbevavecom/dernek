<?php
// Basit veritabanı kurulum scripti
echo "<h2>BEVAVE Dernek Portalı Kurulum</h2>";

try {
    // Veritabanı bağlantısı (database olmadan)
    $pdo = new PDO("mysql:host=localhost", "root", "");
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Veritabanı oluştur
    $pdo->exec("CREATE DATABASE IF NOT EXISTS dernek_portal CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE dernek_portal");
    
    echo "<p>✓ Veritabanı oluşturuldu</p>";

    // Tabloları oluştur
    $sql = "
    -- Kullanıcı roller tablosu
    CREATE TABLE IF NOT EXISTS user_roles (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(50) NOT NULL,
        permissions JSON,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Kullanıcılar tablosu
    CREATE TABLE IF NOT EXISTS users (
        id INT AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(50) NOT NULL UNIQUE,
        password VARCHAR(255) NOT NULL,
        email VARCHAR(100) NOT NULL UNIQUE,
        full_name VARCHAR(100) NOT NULL,
        role_id INT DEFAULT 1,
        phone VARCHAR(20),
        last_login TIMESTAMP NULL,
        status ENUM('active', 'inactive', 'suspended') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    );

    -- Genel ayarlar tablosu
    CREATE TABLE IF NOT EXISTS settings (
        id INT AUTO_INCREMENT PRIMARY KEY,
        setting_key VARCHAR(100) NOT NULL UNIQUE,
        setting_value TEXT,
        setting_type VARCHAR(50),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Üyeler tablosu
    CREATE TABLE IF NOT EXISTS members (
        id INT AUTO_INCREMENT PRIMARY KEY,
        tc_no VARCHAR(11) UNIQUE,
        full_name VARCHAR(100) NOT NULL,
        email VARCHAR(100) UNIQUE,
        phone VARCHAR(20),
        address TEXT,
        membership_date DATE NOT NULL,
        membership_type ENUM('standard', 'premium', 'vip') DEFAULT 'standard',
        status ENUM('active', 'passive', 'deleted') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Bağış yönetimi
    CREATE TABLE IF NOT EXISTS donations (
        id INT AUTO_INCREMENT PRIMARY KEY,
        donor_name VARCHAR(100) NOT NULL,
        amount DECIMAL(10,2) NOT NULL,
        donation_date DATE NOT NULL,
        payment_method ENUM('cash', 'credit_card', 'bank_transfer', 'check') DEFAULT 'cash',
        description TEXT,
        status ENUM('completed', 'pending', 'cancelled') DEFAULT 'completed',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Haber yönetimi
    CREATE TABLE IF NOT EXISTS news (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255) NOT NULL,
        content TEXT NOT NULL,
        summary TEXT,
        featured_image VARCHAR(255),
        author_id INT,
        status ENUM('draft', 'published', 'archived') DEFAULT 'draft',
        views INT DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Galeri yönetimi
    CREATE TABLE IF NOT EXISTS gallery (
        id INT AUTO_INCREMENT PRIMARY KEY,
        title VARCHAR(255),
        image VARCHAR(255) NOT NULL,
        type ENUM('image', 'video') DEFAULT 'image',
        description TEXT,
        category VARCHAR(100),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );

    -- Mesajlar
    CREATE TABLE IF NOT EXISTS messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        email VARCHAR(100) NOT NULL,
        subject VARCHAR(255),
        message TEXT NOT NULL,
        status ENUM('unread', 'read', 'replied') DEFAULT 'unread',
        ip_address VARCHAR(45),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    );
    ";

    // SQL komutlarını ayır ve çalıştır
    $statements = explode(';', $sql);
    foreach ($statements as $statement) {
        if (trim($statement) != '') {
            $pdo->exec($statement);
        }
    }
    
    echo "<p>✓ Tablolar oluşturuldu</p>";

    // Varsayılan verileri ekle
    $pdo->exec("INSERT IGNORE INTO user_roles (id, name, permissions) VALUES 
        (1, 'Administrator', '[\"admin_access\", \"settings_manage\", \"members_manage\", \"content_manage\", \"financial_manage\", \"media_manage\"]'),
        (2, 'Moderator', '[\"content_manage\", \"members_manage\"]'),
        (3, 'User', '[]')");

    $hashed_password = password_hash('password', PASSWORD_DEFAULT);
    $pdo->exec("INSERT IGNORE INTO users (username, password, email, full_name, role_id) VALUES 
        ('admin', '$hashed_password', 'admin@bevave.com', 'Admin User', 1)");

    $pdo->exec("INSERT IGNORE INTO settings (setting_key, setting_value) VALUES 
        ('site_title', 'BEVAVE Dernek Portalı'),
        ('site_description', 'Profesyonel Dernek Yönetim Sistemi'),
        ('contact_email', 'info@bevave.com'),
        ('contact_phone', '+90 212 555 55 55')");

    echo "<p>✓ Varsayılan veriler eklendi</p>";
    
    echo "<div style='background: #d4edda; color: #155724; padding: 15px; border-radius: 5px; margin: 20px 0;'>
            <h3>✓ Kurulum Tamamlandı!</h3>
            <p><strong>Giriş Bilgileri:</strong></p>
            <ul>
                <li>URL: http://localhost/dernek-portal/admin/login.php</li>
                <li>Kullanıcı Adı: admin</li>
                <li>Şifre: password</li>
            </ul>
            <p><a href='admin/login.php' style='background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;'>Yönetim Paneline Git</a></p>
            <p><strong>Güvenlik Notu:</strong> Bu dosyayı sunucudan silin! (install.php)</p>
        </div>";

} catch (PDOException $e) {
    echo "<div style='background: #f8d7da; color: #721c24; padding: 15px; border-radius: 5px;'>
            <h3>✗ Kurulum Hatası</h3>
            <p>Hata: " . $e->getMessage() . "</p>
            <p>Lütfen aşağıdakileri kontrol edin:</p>
            <ul>
                <li>XAMPP/WAMP çalışıyor mu?</li>
                <li>MySQL servisi başlatıldı mı?</li>
                <li>MySQL root şifresi doğru mu? (varsayılan: boş)</li>
            </ul>
        </div>";
}
?>