<?php
require_once 'includes/config.php';
require_once 'includes/functions.php';

// Geliştirme modunda değilse auth kontrolü
if (!defined('DEV_MODE') || DEV_MODE !== true) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: login.php');
        exit;
    }
}

// İstatistikler
try {
    $total_members = $pdo->query("SELECT COUNT(*) FROM members")->fetchColumn();
    $total_donations = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM donations")->fetchColumn();
    $total_news = $pdo->query("SELECT COUNT(*) FROM news")->fetchColumn();
    $unread_messages = $pdo->query("SELECT COUNT(*) FROM messages WHERE status = 'unread'")->fetchColumn();
    
    // Aktif üye sayısı
    $active_members = $pdo->query("SELECT COUNT(*) FROM members WHERE status = 'active'")->fetchColumn();
    
    // Bu ayki bağışlar
    $current_month_donations = $pdo->query("SELECT COALESCE(SUM(amount), 0) FROM donations WHERE MONTH(donation_date) = MONTH(CURRENT_DATE()) AND YEAR(donation_date) = YEAR(CURRENT_DATE())")->fetchColumn();
    
} catch (Exception $e) {
    $total_members = $active_members = $total_donations = $current_month_donations = $total_news = $unread_messages = 0;
}

$page_title = "BEVAVE - Dashboard";
include 'includes/header.php';
?>

<!-- Hoş Geldiniz Mesajı -->
<div class="row mb-4">
    <div class="col-12">
        <div class="card bg-gradient-primary text-white shadow">
            <div class="card-body">
                <div class="row align-items-center">
                    <div class="col-md-8">
                        <h4 class="font-weight-bold">Hoş Geldiniz, <?php echo $_SESSION['full_name'] ?? 'Admin'; ?>! 👋</h4>
                        <p class="mb-0">BEVAVE Dernek Yönetim Sistemine hoş geldiniz. Sistem istatistikleriniz aşağıda yer almaktadır.</p>
                    </div>
                    <div class="col-md-4 text-right">
                        <i class="fas fa-chart-line fa-3x opacity-50"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- İstatistik Kartları -->
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Toplam Üye</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_members; ?></div>
                        <div class="mt-2 text-success">
                            <small><i class="fas fa-user-check"></i> <?php echo $active_members; ?> aktif üye</small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-users fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-success shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-success text-uppercase mb-1">
                            Toplam Bağış</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo number_format($total_donations, 2); ?> TL</div>
                        <div class="mt-2 text-info">
                            <small><i class="fas fa-calendar"></i> Bu ay: <?php echo number_format($current_month_donations, 2); ?> TL</small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-donate fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-info shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-info text-uppercase mb-1">
                            Toplam Haber</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $total_news; ?></div>
                        <div class="mt-2 text-warning">
                            <small><i class="fas fa-eye"></i> Son 30 gün: <?php echo $total_news; ?> haber</small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-newspaper fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-warning shadow h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1">
                            Okunmamış Mesaj</div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo $unread_messages; ?></div>
                        <div class="mt-2 text-danger">
                            <small><i class="fas fa-clock"></i> Cevaplanmayı bekliyor</small>
                        </div>
                    </div>
                    <div class="col-auto">
                        <i class="fas fa-envelope fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <!-- Hızlı Menü -->
    <div class="col-lg-8">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Hızlı Menü</h6>
                <span class="badge badge-primary">Hızlı Erişim</span>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/members/member_management.php" class="btn btn-primary w-100 h-100 py-4 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-users fa-2x mb-2"></i>
                            <span>Üye Yönetimi</span>
                            <small class="text-white-50 mt-1"><?php echo $total_members; ?> üye</small>
                        </a>
                    </div>
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/financial/donation_management.php" class="btn btn-success w-100 h-100 py-4 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-donate fa-2x mb-2"></i>
                            <span>Bağış Yönetimi</span>
                            <small class="text-white-50 mt-1"><?php echo number_format($total_donations, 0); ?> TL</small>
                        </a>
                    </div>
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/content/news_management.php" class="btn btn-info w-100 h-100 py-4 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-newspaper fa-2x mb-2"></i>
                            <span>Haber Yönetimi</span>
                            <small class="text-white-50 mt-1"><?php echo $total_news; ?> haber</small>
                        </a>
                    </div>
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/settings/general_settings.php" class="btn btn-warning w-100 h-100 py-4 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-cogs fa-2x mb-2"></i>
                            <span>Sistem Ayarları</span>
                            <small class="text-white-50 mt-1">Yapılandırma</small>
                        </a>
                    </div>
                </div>
                
                <div class="row mt-3">
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/financial/dues_management.php" class="btn btn-danger w-100 h-100 py-3 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-money-bill-wave fa-2x mb-2"></i>
                            <span>Aidat Yönetimi</span>
                            <small class="text-white-50 mt-1">Ödemeler</small>
                        </a>
                    </div>
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/content/event_management.php" class="btn btn-secondary w-100 h-100 py-3 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-calendar-alt fa-2x mb-2"></i>
                            <span>Etkinlikler</span>
                            <small class="text-white-50 mt-1">Takvim</small>
                        </a>
                    </div>
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/members/member_groups.php" class="btn btn-dark w-100 h-100 py-3 d-flex flex-column align-items-center justify-content-center">
                            <i class="fas fa-user-friends fa-2x mb-2"></i>
                            <span>Üye Grupları</span>
                            <small class="text-white-50 mt-1">Gruplar</small>
                        </a>
                    </div>
                    <div class="col-md-3 mb-3 text-center">
                        <a href="modules/messages.php" class="btn btn-light w-100 h-100 py-3 d-flex flex-column align-items-center justify-content-center border">
                            <i class="fas fa-envelope fa-2x mb-2 text-dark"></i>
                            <span class="text-dark">Mesajlar</span>
                            <?php if ($unread_messages > 0): ?>
                                <span class="badge badge-danger mt-1"><?php echo $unread_messages; ?> yeni</span>
                            <?php else: ?>
                                <small class="text-muted mt-1">Mesajlar</small>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Son Aktiviteler -->
    <div class="col-lg-4">
        <div class="card shadow mb-4">
            <div class="card-header py-3 d-flex justify-content-between align-items-center">
                <h6 class="m-0 font-weight-bold text-primary">Son Aktiviteler</h6>
                <span class="badge badge-info">Canlı</span>
            </div>
            <div class="card-body" style="max-height: 400px; overflow-y: auto;">
                <?php
                try {
                    // Son 8 aktiviteyi getir
                    $activities = $pdo->query("
                        (SELECT 'member' as type, full_name as title, created_at, 'Yeni üye kaydı' as description FROM members ORDER BY created_at DESC LIMIT 3)
                        UNION ALL
                        (SELECT 'donation' as type, donor_name as title, created_at, CONCAT(amount, ' TL bağış') as description FROM donations ORDER BY created_at DESC LIMIT 3)
                        UNION ALL
                        (SELECT 'news' as type, title, created_at, 'Yeni haber yayınlandı' as description FROM news ORDER BY created_at DESC LIMIT 2)
                        ORDER BY created_at DESC LIMIT 8
                    ")->fetchAll();
                    
                    if (empty($activities)) {
                        echo '<div class="text-center text-muted py-4">
                                <i class="fas fa-info-circle fa-2x mb-3"></i><br>
                                Henüz aktivite bulunmuyor.
                              </div>';
                    } else {
                        foreach ($activities as $index => $activity) {
                            $icon = '';
                            $bg_color = '';
                            $text_color = '';
                            
                            switch ($activity['type']) {
                                case 'member':
                                    $icon = 'fa-user-plus';
                                    $bg_color = '#dbeafe';
                                    $text_color = 'text-primary';
                                    break;
                                case 'donation':
                                    $icon = 'fa-donate';
                                    $bg_color = '#d1fae5';
                                    $text_color = 'text-success';
                                    break;
                                case 'news':
                                    $icon = 'fa-newspaper';
                                    $bg_color = '#fef3c7';
                                    $text_color = 'text-warning';
                                    break;
                            }
                            
                            $time_ago = time_elapsed_string($activity['created_at']);
                            ?>
                            <div class="activity-item mb-3 pb-3 <?php echo $index < count($activities) - 1 ? 'border-bottom' : ''; ?>">
                                <div class="d-flex align-items-start">
                                    <div class="flex-shrink-0">
                                        <div class="activity-icon rounded-circle d-flex align-items-center justify-content-center" 
                                             style="width: 40px; height: 40px; background: <?php echo $bg_color; ?>;">
                                            <i class="fas <?php echo $icon; ?> <?php echo $text_color; ?>"></i>
                                        </div>
                                    </div>
                                    <div class="flex-grow-1 ms-3">
                                        <h6 class="mb-1 font-weight-bold"><?php echo $activity['title']; ?></h6>
                                        <p class="mb-1 text-muted small"><?php echo $activity['description']; ?></p>
                                        <small class="text-muted"><i class="fas fa-clock"></i> <?php echo $time_ago; ?></small>
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    }
                } catch (Exception $e) {
                    echo '<div class="alert alert-warning text-center">
                            <i class="fas fa-exclamation-triangle"></i><br>
                            Aktiviteler yüklenirken hata oluştu.
                          </div>';
                }
                ?>
            </div>
        </div>
    </div>
</div>

<!-- Sistem Durumu -->
<div class="row">
    <div class="col-12">
        <div class="card shadow">
            <div class="card-header py-3">
                <h6 class="m-0 font-weight-bold text-primary">Sistem Durumu</h6>
            </div>
            <div class="card-body">
                <div class="row text-center">
                    <div class="col-md-2 mb-3">
                        <div class="system-status-item">
                            <div class="status-icon text-success mb-2">
                                <i class="fas fa-database fa-2x"></i>
                            </div>
                            <h6 class="font-weight-bold">Veritabanı</h6>
                            <span class="badge badge-success">Aktif</span>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <div class="system-status-item">
                            <div class="status-icon text-success mb-2">
                                <i class="fas fa-server fa-2x"></i>
                            </div>
                            <h6 class="font-weight-bold">Sunucu</h6>
                            <span class="badge badge-success">Çalışıyor</span>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <div class="system-status-item">
                            <div class="status-icon text-info mb-2">
                                <i class="fas fa-code fa-2x"></i>
                            </div>
                            <h6 class="font-weight-bold">PHP</h6>
                            <span class="badge badge-info">v<?php echo PHP_VERSION; ?></span>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <div class="system-status-item">
                            <div class="status-icon text-primary mb-2">
                                <i class="fas fa-shield-alt fa-2x"></i>
                            </div>
                            <h6 class="font-weight-bold">Güvenlik</h6>
                            <span class="badge badge-primary">Aktif</span>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <div class="system-status-item">
                            <div class="status-icon text-warning mb-2">
                                <i class="fas fa-hdd fa-2x"></i>
                            </div>
                            <h6 class="font-weight-bold">Depolama</h6>
                            <span class="badge badge-warning">%65</span>
                        </div>
                    </div>
                    <div class="col-md-2 mb-3">
                        <div class="system-status-item">
                            <div class="status-icon text-success mb-2">
                                <i class="fas fa-bolt fa-2x"></i>
                            </div>
                            <h6 class="font-weight-bold">Performans</h6>
                            <span class="badge badge-success">İyi</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.system-status-item {
    padding: 15px;
    border-radius: 8px;
    transition: all 0.3s ease;
}

.system-status-item:hover {
    background-color: #f8f9fa;
    transform: translateY(-2px);
}

.activity-item {
    transition: all 0.3s ease;
}

.activity-item:hover {
    background-color: #f8f9fa;
    border-radius: 8px;
    margin-left: -5px;
    margin-right: -5px;
    padding-left: 5px;
    padding-right: 5px;
}

.btn {
    transition: all 0.3s ease;
    border: none;
}

.btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.2);
}

.card {
    transition: all 0.3s ease;
}

.card:hover {
    box-shadow: 0 4px 20px rgba(0,0,0,0.15);
}
</style>

<?php include 'includes/footer.php'; ?>