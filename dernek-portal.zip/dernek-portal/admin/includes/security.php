<?php
// Admin güvenlik kontrolleri

// File upload güvenliği
function secureFileUpload($file, $allowed_types = ['jpg', 'jpeg', 'png', 'gif', 'pdf']) {
    $max_size = 5 * 1024 * 1024; // 5MB
    $file_name = $file['name'];
    $file_size = $file['size'];
    $file_tmp = $file['tmp_name'];
    $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
    
    // Dosya boyutu kontrolü
    if ($file_size > $max_size) {
        return ['success' => false, 'error' => 'Dosya boyutu 5MB\'dan küçük olmalıdır'];
    }
    
    // Dosya tipi kontrolü
    if (!in_array($file_ext, $allowed_types)) {
        return ['success' => false, 'error' => 'Geçersiz dosya formatı'];
    }
    
    // Güvenli dosya adı oluştur
    $new_filename = uniqid() . '_' . time() . '.' . $file_ext;
    $upload_path = '../assets/uploads/' . $new_filename;
    
    // Uploads klasörünü kontrol et ve oluştur
    $upload_dir = dirname($upload_path);
    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0755, true);
    }
    
    if (move_uploaded_file($file_tmp, $upload_path)) {
        return ['success' => true, 'filename' => $new_filename];
    } else {
        return ['success' => false, 'error' => 'Dosya yüklenirken hata oluştu'];
    }
}

// SQL injection koruması
function secureSQL($pdo, $query, $params = []) {
    try {
        $stmt = $pdo->prepare($query);
        $stmt->execute($params);
        return $stmt;
    } catch (PDOException $e) {
        error_log("SQL Error: " . $e->getMessage());
        return false;
    }
}

// Rate limiting
function checkRateLimit($action, $limit = 10, $timeframe = 60) {
    $key = "rate_limit_{$action}_" . ($_SERVER['REMOTE_ADDR'] ?? '');
    
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = ['count' => 1, 'time' => time()];
        return true;
    }
    
    $data = $_SESSION[$key];
    
    if (time() - $data['time'] > $timeframe) {
        $_SESSION[$key] = ['count' => 1, 'time' => time()];
        return true;
    }
    
    if ($data['count'] >= $limit) {
        return false;
    }
    
    $_SESSION[$key]['count']++;
    return true;
}
?>