<?php
// Session başlat (sadece bir kez)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Veritabanı bağlantısı
try {
    $host = 'localhost';
    $dbname = 'dernek_portal';
    $username = 'root';
    $password = '';
    
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
} catch(PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}

// Geliştirme modu - otomatik login
define('DEV_MODE', true);

// Geliştirme modunda test kullanıcısı
if (DEV_MODE && !isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = 1;
    $_SESSION['full_name'] = 'Admin Kullanıcı';
    $_SESSION['role'] = 'admin';
    $_SESSION['email'] = 'admin@bevave.com';
}
?>