<nav class="sidebar-menu">
    <!-- Ana Menü -->
    <div class="menu-section">
        <div class="menu-title">Ana Menü</div>
        <ul class="menu-items">
            <li class="menu-item">
                <a href="../index.php" class="menu-link <?php echo $current_page == 'index.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-home"></i>
                    <span class="menu-text">Dashboard</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Üye Yönetimi -->
    <div class="menu-section">
        <div class="menu-title">Üye Yönetimi</div>
        <ul class="menu-items">
            <li class="menu-item">
                <a href="modules/members/member_management.php" class="menu-link <?php echo $current_page == 'member_management.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-users"></i>
                    <span class="menu-text">Üye Yönetimi</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="modules/members/member_groups.php" class="menu-link <?php echo $current_page == 'member_groups.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-user-friends"></i>
                    <span class="menu-text">Üye Grupları</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Finansal Yönetim -->
    <div class="menu-section">
        <div class="menu-title">Finansal Yönetim</div>
        <ul class="menu-items">
            <li class="menu-item">
                <a href="modules/financial/donation_management.php" class="menu-link <?php echo $current_page == 'donation_management.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-donate"></i>
                    <span class="menu-text">Bağış Yönetimi</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="modules/financial/dues_management.php" class="menu-link <?php echo $current_page == 'dues_management.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-money-bill-wave"></i>
                    <span class="menu-text">Aidat Yönetimi</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- İçerik Yönetimi -->
    <div class="menu-section">
        <div class="menu-title">İçerik Yönetimi</div>
        <ul class="menu-items">
            <li class="menu-item">
                <a href="modules/content/news_management.php" class="menu-link <?php echo $current_page == 'news_management.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-newspaper"></i>
                    <span class="menu-text">Haber Yönetimi</span>
                </a>
            </li>
            <li class="menu-item">
                <a href="modules/content/event_management.php" class="menu-link <?php echo $current_page == 'event_management.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-calendar-alt"></i>
                    <span class="menu-text">Etkinlik Yönetimi</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Site Yönetimi -->
    <div class="menu-section">
        <div class="menu-title">Site Yönetimi</div>
        <ul class="menu-items">
            <li class="menu-item">
                <a href="modules/settings/general_settings.php" class="menu-link <?php echo $current_page == 'general_settings.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-cogs"></i>
                    <span class="menu-text">Genel Ayarlar</span>
                </a>
            </li>
        </ul>
    </div>
    
    <!-- Diğer -->
    <div class="menu-section">
        <div class="menu-title">Diğer</div>
        <ul class="menu-items">
            <li class="menu-item">
                <a href="modules/messages.php" class="menu-link <?php echo $current_page == 'messages.php' ? 'active' : ''; ?>">
                    <i class="menu-icon fas fa-envelope"></i>
                    <span class="menu-text">Mesajlar</span>
                    <?php if ($unread_messages > 0): ?>
                        <span class="menu-badge"><?php echo $unread_messages; ?></span>
                    <?php endif; ?>
                </a>
            </li>
            <li class="menu-item">
                <a href="../login.php?logout=1" class="menu-link">
                    <i class="menu-icon fas fa-sign-out-alt"></i>
                    <span class="menu-text">Çıkış</span>
                </a>
            </li>
        </ul>
    </div>
</nav>