<?php
require_once '../../../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$success = '';
$error = '';

// Duyuruları getir
$announcements = [];
try {
    $stmt = $pdo->query("SELECT a.*, u.username as author_name 
                         FROM announcements a 
                         LEFT JOIN users u ON a.author_id = u.id 
                         ORDER BY a.created_at DESC");
    $announcements = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Duyurular yüklenirken hata oluştu: " . $e->getMessage();
}

// Duyuru ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_announcement'])) {
    try {
        $title = sanitizeInput($_POST['title']);
        $content = $_POST['content'];
        $status = sanitizeInput($_POST['status']);
        $start_date = $_POST['start_date'] ?: date('Y-m-d');
        $end_date = $_POST['end_date'];
        $author_id = $_SESSION['user_id'];
        
        $stmt = $pdo->prepare("INSERT INTO announcements (title, content, status, start_date, end_date, author_id) 
                              VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$title, $content, $status, $start_date, $end_date, $author_id])) {
            $success = "Duyuru başarıyla eklendi!";
        }
    } catch(Exception $e) {
        $error = "Duyuru eklenirken hata oluştu: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Duyuru Yönetimi - BEVAVE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <!-- Sidebar ve Header -->
    
    <div class="main-content">
        <div class="header">
            <h1>Duyuru Yönetimi</h1>
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Yeni Duyuru
            </button>
        </div>
        
        <div class="content">
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Başlık</th>
                                    <th>Yazar</th>
                                    <th>Başlangıç</th>
                                    <th>Bitiş</th>
                                    <th>Durum</th>
                                    <th>İşlemler</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach($announcements as $announcement): ?>
                                <tr>
                                    <td><?php echo $announcement['title']; ?></td>
                                    <td><?php echo $announcement['author_name']; ?></td>
                                    <td><?php echo date('d.m.Y', strtotime($announcement['start_date'])); ?></td>
                                    <td><?php echo $announcement['end_date'] ? date('d.m.Y', strtotime($announcement['end_date'])) : '-'; ?></td>
                                    <td>
                                        <span class="badge badge-<?php echo $announcement['status'] == 'published' ? 'success' : 'warning'; ?>">
                                            <?php echo $announcement['status'] == 'published' ? 'Yayında' : 'Taslak'; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="?edit=<?php echo $announcement['id']; ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="?delete=<?php echo $announcement['id']; ?>" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div id="announcementModal" class="modal">
        <div class="modal-content modal-lg">
            <div class="modal-header">
                <h3>Yeni Duyuru</h3>
                <button type="button" class="close" onclick="closeModal()">&times;</button>
            </div>
            <form method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Başlık</label>
                        <input type="text" name="title" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>İçerik</label>
                        <textarea name="content" class="form-control" rows="10" required></textarea>
                    </div>
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label>Başlangıç Tarihi</label>
                                <input type="date" name="start_date" class="form-control" value="<?php echo date('Y-m-d'); ?>">
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group">
                                <label>Bitiş Tarihi</label>
                                <input type="date" name="end_date" class="form-control">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Durum</label>
                        <select name="status" class="form-control">
                            <option value="draft">Taslak</option>
                            <option value="published">Yayında</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                    <button type="submit" name="add_announcement" class="btn btn-primary">Kaydet</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal() {
            document.getElementById('announcementModal').style.display = 'block';
        }
        function closeModal() {
            document.getElementById('announcementModal').style.display = 'none';
        }
    </script>
</body>
</html>