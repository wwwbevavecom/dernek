<?php
require_once '../../../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$success = '';
$error = '';

// Sayfaları getir
$pages = [];
try {
    $stmt = $pdo->query("SELECT * FROM pages ORDER BY created_at DESC");
    $pages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Sayfalar yüklenirken hata oluştu: " . $e->getMessage();
}

// Sayfa ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_page'])) {
    try {
        $title = sanitizeInput($_POST['title']);
        $content = $_POST['content'];
        $slug = sanitizeInput($_POST['slug']);
        $meta_description = sanitizeInput($_POST['meta_description']);
        $status = sanitizeInput($_POST['status']);
        
        // Slug oluştur
        if (empty($slug)) {
            $slug = strtolower(str_replace(' ', '-', $title));
            $slug = preg_replace('/[^a-z0-9\-]/', '', $slug);
        }
        
        $stmt = $pdo->prepare("INSERT INTO pages (title, content, slug, meta_description, status) 
                              VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$title, $content, $slug, $meta_description, $status])) {
            $success = "Sayfa başarıyla eklendi!";
        }
    } catch(Exception $e) {
        $error = "Sayfa eklenirken hata oluştu: " . $e->getMessage();
    }
}
?>
<!-- HTML yapısı duyuru yönetimiyle benzer -->