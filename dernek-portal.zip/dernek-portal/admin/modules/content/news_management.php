<?php
define('ADMIN_PATH', true);
require_once '../../../includes/config.php';
require_once '../../../includes/auth.php';
require_once '../../includes/security.php';

if (!$auth->isLoggedIn() || !$auth->hasPermission('content_manage')) {
    header('Location: ../login.php');
    exit;
}

$success = $error = '';

// Haber listeleme
$news = [];
try {
    $stmt = $pdo->query("SELECT n.*, u.username as author_name 
                         FROM news n 
                         LEFT JOIN users u ON n.author_id = u.id 
                         ORDER BY n.created_at DESC");
    $news = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Haberler yüklenirken hata oluştu: " . $e->getMessage();
}

// Haber ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_news']) && verifyCSRFToken($_POST['csrf_token'])) {
    try {
        $title = sanitizeInput($_POST['title']);
        $content = $_POST['content'];
        $summary = sanitizeInput($_POST['summary']);
        $status = sanitizeInput($_POST['status']);
        $author_id = $_SESSION['user_id'];
        
        $stmt = $pdo->prepare("INSERT INTO news (title, content, summary, status, author_id) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$title, $content, $summary, $status, $author_id])) {
            $news_id = $pdo->lastInsertId();
            
            // Resim yükleme
            if (!empty($_FILES['featured_image']['name'])) {
                $upload_result = secureFileUpload($_FILES['featured_image']);
                if ($upload_result['success']) {
                    $stmt = $pdo->prepare("UPDATE news SET featured_image = ? WHERE id = ?");
                    $stmt->execute([$upload_result['filename'], $news_id]);
                }
            }
            
            $success = "Haber başarıyla eklendi!";
        }
    } catch(Exception $e) {
        $error = "Haber eklenirken hata oluştu: " . $e->getMessage();
    }
}

$page_title = "Haber Yönetimi - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-newspaper"></i> Haber Yönetimi</h1>
            <p>BEVAVE haber içeriklerini yönetin</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Yeni Haber Ekle
            </button>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Haber Listesi -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Haber Listesi</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Başlık</th>
                            <th>Özet</th>
                            <th>Yazar</th>
                            <th>Durum</th>
                            <th>Tarih</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($news as $item): ?>
                        <tr>
                            <td><?php echo $item['id']; ?></td>
                            <td>
                                <strong><?php echo htmlspecialchars($item['title']); ?></strong>
                                <?php if ($item['featured_image']): ?>
                                    <br><small class="text-muted"><i class="fas fa-image"></i> Resimli</small>
                                <?php endif; ?>
                            </td>
                            <td><?php echo mb_substr($item['summary'], 0, 100) . '...'; ?></td>
                            <td><?php echo $item['author_name']; ?></td>
                            <td>
                                <span class="badge badge-<?php echo $item['status'] == 'published' ? 'success' : 'warning'; ?>">
                                    <?php echo $item['status'] == 'published' ? 'Yayında' : 'Taslak'; ?>
                                </span>
                            </td>
                            <td><?php echo date('d.m.Y H:i', strtotime($item['created_at'])); ?></td>
                            <td>
                                <div class="btn-group">
                                    <a href="news_edit.php?id=<?php echo $item['id']; ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $item['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Bu haberi silmek istediğinizden emin misiniz?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="newsModal" class="modal">
    <div class="modal-content modal-lg">
        <div class="modal-header">
            <h3>Yeni Haber Ekle</h3>
            <button type="button" class="close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label>Haber Başlığı *</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Haber Özeti *</label>
                    <textarea name="summary" class="form-control" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label>Haber İçeriği *</label>
                    <textarea name="content" class="form-control" rows="10" required></textarea>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>Kapak Resmi</label>
                            <input type="file" name="featured_image" class="form-control" accept="image/*">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label>Durum</label>
                            <select name="status" class="form-control">
                                <option value="draft">Taslak</option>
                                <option value="published">Yayında</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_news" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('newsModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('newsModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('newsModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include '../../includes/header.php'; ?>