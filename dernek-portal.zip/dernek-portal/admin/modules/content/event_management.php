<?php
require_once '../../../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$success = '';
$error = '';

// Etkinlikleri getir
$events = [];
try {
    $stmt = $pdo->query("SELECT * FROM events ORDER BY event_date DESC");
    $events = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Etkinlikler yüklenirken hata oluştu: " . $e->getMessage();
}

// Etkinlik ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_event'])) {
    try {
        $title = sanitizeInput($_POST['title']);
        $description = sanitizeInput($_POST['description']);
        $event_date = $_POST['event_date'];
        $event_time = $_POST['event_time'];
        $location = sanitizeInput($_POST['location']);
        $max_participants = intval($_POST['max_participants']);
        
        $stmt = $pdo->prepare("INSERT INTO events (title, description, event_date, event_time, location, max_participants) 
                              VALUES (?, ?, ?, ?, ?, ?)");
        if ($stmt->execute([$title, $description, $event_date, $event_time, $location, $max_participants])) {
            $success = "Etkinlik başarıyla eklendi!";
        }
    } catch(Exception $e) {
        $error = "Etkinlik eklenirken hata oluştu: " . $e->getMessage();
    }
}
?>
<!-- HTML yapısı duyuru yönetimiyle benzer -->