<?php
require_once '../../../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$success = '';
$error = '';

// Sliderları getir
$sliders = [];
try {
    $stmt = $pdo->query("SELECT * FROM sliders ORDER BY sort_order ASC");
    $sliders = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Sliderlar yüklenirken hata oluştu: " . $e->getMessage();
}

// Slider ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_slider'])) {
    try {
        $title = sanitizeInput($_POST['title']);
        $description = sanitizeInput($_POST['description']);
        $button_text = sanitizeInput($_POST['button_text']);
        $button_url = sanitizeInput($_POST['button_url']);
        $sort_order = intval($_POST['sort_order']);
        
        // Resim yükleme
        $image = '';
        if (!empty($_FILES['image']['name'])) {
            $upload_result = secureFileUpload($_FILES['image']);
            if ($upload_result['success']) {
                $image = $upload_result['filename'];
            } else {
                $error = $upload_result['error'];
            }
        }
        
        if (empty($error)) {
            $stmt = $pdo->prepare("INSERT INTO sliders (title, image, description, button_text, button_url, sort_order) 
                                  VALUES (?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$title, $image, $description, $button_text, $button_url, $sort_order])) {
                $success = "Slider başarıyla eklendi!";
            }
        }
    } catch(Exception $e) {
        $error = "Slider eklenirken hata oluştu: " . $e->getMessage();
    }
}
?>
<!-- HTML yapısı foto galeriyle benzer -->