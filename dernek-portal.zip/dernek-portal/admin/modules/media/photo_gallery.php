<?php
define('ADMIN_PATH', true);
require_once '../../../includes/config.php';
require_once '../../../includes/auth.php';
require_once '../../includes/security.php';

if (!$auth->isLoggedIn() || !$auth->hasPermission('media_manage')) {
    header('Location: ../login.php');
    exit;
}

$success = $error = '';

// Galeri listeleme
$photos = [];
try {
    $stmt = $pdo->query("SELECT * FROM gallery WHERE type = 'photo' ORDER BY created_at DESC");
    $photos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Fotoğraflar yüklenirken hata oluştu: " . $e->getMessage();
}

// Fotoğraf yükleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['upload_photos']) && verifyCSRFToken($_POST['csrf_token'])) {
    try {
        $title = sanitizeInput($_POST['title']);
        $description = sanitizeInput($_POST['description']);
        $category = sanitizeInput($_POST['category']);
        
        if (!empty($_FILES['photos']['name'][0])) {
            $uploaded_count = 0;
            
            foreach ($_FILES['photos']['tmp_name'] as $key => $tmp_name) {
                $file = [
                    'name' => $_FILES['photos']['name'][$key],
                    'type' => $_FILES['photos']['type'][$key],
                    'tmp_name' => $tmp_name,
                    'error' => $_FILES['photos']['error'][$key],
                    'size' => $_FILES['photos']['size'][$key]
                ];
                
                $upload_result = secureFileUpload($file);
                
                if ($upload_result['success']) {
                    $stmt = $pdo->prepare("INSERT INTO gallery (title, image, description, category, type) VALUES (?, ?, ?, ?, 'photo')");
                    $stmt->execute([$title, $upload_result['filename'], $description, $category]);
                    $uploaded_count++;
                }
            }
            
            $success = "$uploaded_count fotoğraf başarıyla yüklendi!";
        } else {
            $error = "Lütfen en az bir fotoğraf seçin!";
        }
    } catch(Exception $e) {
        $error = "Fotoğraf yüklenirken hata oluştu: " . $e->getMessage();
    }
}

$page_title = "Foto Galeri - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-images"></i> Foto Galeri</h1>
            <p>BEVAVE fotoğraf galerisini yönetin</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-upload"></i> Fotoğraf Yükle
            </button>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Fotoğraf Grid -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-th"></i> Fotoğraflar (<?php echo count($photos); ?>)</h3>
        </div>
        <div class="card-body">
            <?php if (empty($photos)): ?>
                <div class="text-center text-muted py-5">
                    <i class="fas fa-images fa-3x mb-3"></i>
                    <p>Henüz fotoğraf yüklenmemiş</p>
                </div>
            <?php else: ?>
                <div class="row">
                    <?php foreach($photos as $photo): ?>
                    <div class="col-md-3 mb-4">
                        <div class="gallery-item">
                            <div class="gallery-image">
                                <img src="../assets/uploads/<?php echo $photo['image']; ?>" 
                                     alt="<?php echo htmlspecialchars($photo['title']); ?>" 
                                     class="img-fluid">
                                <div class="gallery-overlay">
                                    <div class="gallery-actions">
                                        <a href="../assets/uploads/<?php echo $photo['image']; ?>" 
                                           class="btn btn-sm btn-light" target="_blank">
                                            <i class="fas fa-expand"></i>
                                        </a>
                                        <a href="?delete=<?php echo $photo['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" 
                                           class="btn btn-sm btn-danger"
                                           onclick="return confirm('Bu fotoğrafı silmek istediğinizden emin misiniz?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="gallery-info">
                                <h6><?php echo htmlspecialchars($photo['title']); ?></h6>
                                <?php if ($photo['category']): ?>
                                    <span class="badge badge-primary"><?php echo $photo['category']; ?></span>
                                <?php endif; ?>
                                <small class="text-muted"><?php echo date('d.m.Y', strtotime($photo['created_at'])); ?></small>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="uploadModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Fotoğraf Yükle</h3>
            <button type="button" class="close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label>Başlık *</label>
                    <input type="text" name="title" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label>Kategori</label>
                    <input type="text" name="category" class="form-control" placeholder="Etkinlik, Toplantı, Genel...">
                </div>
                <div class="form-group">
                    <label>Fotoğraflar *</label>
                    <input type="file" name="photos[]" class="form-control" multiple accept="image/*" required>
                    <small class="form-text text-muted">Birden fazla fotoğraf seçebilirsiniz (JPEG, PNG, GIF)</small>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="upload_photos" class="btn btn-primary">Yükle</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('uploadModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('uploadModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('uploadModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<style>
.gallery-item {
    border: 1px solid #e1e5e9;
    border-radius: 8px;
    overflow: hidden;
    transition: transform 0.3s;
}

.gallery-item:hover {
    transform: translateY(-5px);
}

.gallery-image {
    position: relative;
    overflow: hidden;
    height: 200px;
}

.gallery-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.gallery-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.7);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s;
}

.gallery-item:hover .gallery-overlay {
    opacity: 1;
}

.gallery-info {
    padding: 15px;
}

.gallery-info h6 {
    margin-bottom: 5px;
    font-size: 14px;
}
</style>

<?php include '../../includes/footer.php'; ?>