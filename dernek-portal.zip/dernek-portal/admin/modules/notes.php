<?php
require_once '../../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$success = '';
$error = '';

// Notları getir
$notes = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM notes WHERE user_id = ? ORDER BY updated_at DESC");
    $stmt->execute([$_SESSION['user_id']]);
    $notes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    // Tablo yoksa oluştur
    $pdo->exec("CREATE TABLE IF NOT EXISTS notes (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT,
        title VARCHAR(255) NOT NULL,
        content TEXT,
        color VARCHAR(7) DEFAULT '#ffffff',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    )");
}

// Not ekleme/güncelleme
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $title = sanitizeInput($_POST['title']);
        $content = sanitizeInput($_POST['content']);
        $color = sanitizeInput($_POST['color']);
        
        if (isset($_POST['note_id']) && !empty($_POST['note_id'])) {
            // Güncelleme
            $note_id = intval($_POST['note_id']);
            $stmt = $pdo->prepare("UPDATE notes SET title = ?, content = ?, color = ? WHERE id = ? AND user_id = ?");
            if ($stmt->execute([$title, $content, $color, $note_id, $_SESSION['user_id']])) {
                $success = "Not başarıyla güncellendi!";
            }
        } else {
            // Ekleme
            $stmt = $pdo->prepare("INSERT INTO notes (user_id, title, content, color) VALUES (?, ?, ?, ?)");
            if ($stmt->execute([$_SESSION['user_id'], $title, $content, $color])) {
                $success = "Not başarıyla eklendi!";
            }
        }
    } catch(Exception $e) {
        $error = "Not kaydedilirken hata oluştu: " . $e->getMessage();
    }
}

// Not silme
if (isset($_GET['delete'])) {
    try {
        $id = intval($_GET['delete']);
        $stmt = $pdo->prepare("DELETE FROM notes WHERE id = ? AND user_id = ?");
        if ($stmt->execute([$id, $_SESSION['user_id']])) {
            $success = "Not başarıyla silindi!";
        }
    } catch(Exception $e) {
        $error = "Not silinirken hata oluştu: " . $e->getMessage();
    }
}
?>
<!-- HTML yapısı diğer modüllerle benzer -->