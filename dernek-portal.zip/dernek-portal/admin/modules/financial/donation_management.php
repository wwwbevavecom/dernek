<?php
define('ADMIN_PATH', true);
require_once '../../../includes/config.php';
require_once '../../../includes/auth.php';
require_once '../../includes/security.php';

if (!$auth->isLoggedIn() || !$auth->hasPermission('financial_manage')) {
    header('Location: ../login.php');
    exit;
}

$success = $error = '';

// Bağış listeleme
$donations = [];
$filter_year = $_GET['year'] ?? date('Y');
$filter_month = $_GET['month'] ?? '';

try {
    $sql = "SELECT * FROM donations WHERE YEAR(donation_date) = ?";
    $params = [$filter_year];
    
    if (!empty($filter_month)) {
        $sql .= " AND MONTH(donation_date) = ?";
        $params[] = $filter_month;
    }
    
    $sql .= " ORDER BY donation_date DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $donations = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Toplam bağış
    $total_sql = "SELECT COALESCE(SUM(amount), 0) as total FROM donations WHERE YEAR(donation_date) = ?";
    $total_stmt = $pdo->prepare($total_sql);
    $total_stmt->execute([$filter_year]);
    $total_donation = $total_stmt->fetchColumn();
} catch(Exception $e) {
    $error = "Bağışlar yüklenirken hata oluştu: " . $e->getMessage();
}

// Bağış ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_donation']) && verifyCSRFToken($_POST['csrf_token'])) {
    try {
        $donor_name = sanitizeInput($_POST['donor_name']);
        $amount = floatval($_POST['amount']);
        $donation_date = $_POST['donation_date'];
        $payment_method = sanitizeInput($_POST['payment_method']);
        $description = sanitizeInput($_POST['description']);
        
        $stmt = $pdo->prepare("INSERT INTO donations (donor_name, amount, donation_date, payment_method, description) VALUES (?, ?, ?, ?, ?)");
        if ($stmt->execute([$donor_name, $amount, $donation_date, $payment_method, $description])) {
            $success = "Bağış başarıyla eklendi!";
        }
    } catch(Exception $e) {
        $error = "Bağış eklenirken hata oluştu: " . $e->getMessage();
    }
}

$page_title = "Bağış Yönetimi - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-donate"></i> Bağış Yönetimi</h1>
            <p>BEVAVE bağış kayıtlarını yönetin</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Yeni Bağış Ekle
            </button>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- İstatistikler -->
    <div class="row">
        <div class="col-3">
            <div class="stat-card primary">
                <div class="stat-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo number_format($total_donation, 2); ?> TL</h3>
                    <p>Toplam Bağış</p>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="stat-card success">
                <div class="stat-icon">
                    <i class="fas fa-hand-holding-usd"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo count($donations); ?></h3>
                    <p>Toplam Bağış Sayısı</p>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="stat-card info">
                <div class="stat-icon">
                    <i class="fas fa-calendar"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo $filter_year; ?></h3>
                    <p>Yıl</p>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="stat-card warning">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-info">
                    <h3><?php echo count(array_unique(array_column($donations, 'donor_name'))); ?></h3>
                    <p>Farklı Bağışçı</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtreleme -->
    <div class="card">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <select name="year" class="form-control">
                        <?php for($y = date('Y'); $y >= 2020; $y--): ?>
                            <option value="<?php echo $y; ?>" <?php echo $filter_year == $y ? 'selected' : ''; ?>>
                                <?php echo $y; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <select name="month" class="form-control">
                        <option value="">Tüm Aylar</option>
                        <?php for($m = 1; $m <= 12; $m++): ?>
                            <option value="<?php echo $m; ?>" <?php echo $filter_month == $m ? 'selected' : ''; ?>>
                                <?php echo DateTime::createFromFormat('!m', $m)->format('F'); ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter"></i> Filtrele
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Bağış Listesi -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Bağış Listesi</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Bağışçı Adı</th>
                            <th>Miktar</th>
                            <th>Bağış Tarihi</th>
                            <th>Ödeme Yöntemi</th>
                            <th>Açıklama</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($donations as $donation): ?>
                        <tr>
                            <td><?php echo $donation['id']; ?></td>
                            <td><strong><?php echo htmlspecialchars($donation['donor_name']); ?></strong></td>
                            <td>
                                <span class="text-success font-weight-bold">
                                    <?php echo number_format($donation['amount'], 2); ?> TL
                                </span>
                            </td>
                            <td><?php echo date('d.m.Y', strtotime($donation['donation_date'])); ?></td>
                            <td>
                                <?php
                                $payment_methods = [
                                    'cash' => 'Nakit',
                                    'credit_card' => 'Kredi Kartı',
                                    'bank_transfer' => 'Banka Transferi',
                                    'check' => 'Çek'
                                ];
                                echo $payment_methods[$donation['payment_method']] ?? $donation['payment_method'];
                                ?>
                            </td>
                            <td><?php echo $donation['description']; ?></td>
                            <td>
                                <span class="badge badge-<?php echo $donation['status'] == 'completed' ? 'success' : 'warning'; ?>">
                                    <?php echo $donation['status'] == 'completed' ? 'Tamamlandı' : 'Bekliyor'; ?>
                                </span>
                            </td>
                            <td>
                                <div class="btn-group">
                                    <a href="donation_edit.php?id=<?php echo $donation['id']; ?>" class="btn btn-sm btn-warning">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <a href="?delete=<?php echo $donation['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" 
                                       class="btn btn-sm btn-danger"
                                       onclick="return confirm('Bu bağışı silmek istediğinizden emin misiniz?')">
                                        <i class="fas fa-trash"></i>
                                    </a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="donationModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Yeni Bağış Ekle</h3>
            <button type="button" class="close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label>Bağışçı Adı *</label>
                    <input type="text" name="donor_name" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Miktar (TL) *</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="0" required>
                </div>
                <div class="form-group">
                    <label>Bağış Tarihi *</label>
                    <input type="date" name="donation_date" class="form-control" required value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label>Ödeme Yöntemi *</label>
                    <select name="payment_method" class="form-control" required>
                        <option value="cash">Nakit</option>
                        <option value="credit_card">Kredi Kartı</option>
                        <option value="bank_transfer">Banka Transferi</option>
                        <option value="check">Çek</option>
                    </select>
                </div>
                <div class="form-group">
                    <label>Açıklama</label>
                    <textarea name="description" class="form-control" rows="3"></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_donation" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('donationModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('donationModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('donationModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include '../../includes/footer.php'; ?>