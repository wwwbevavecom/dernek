<?php
require_once '../../../includes/config.php';

// Basit auth kontrolü
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$success = '';
$error = '';

// Filtreleme parametreleri
$member_id = $_GET['member_id'] ?? '';
$year = $_GET['year'] ?? date('Y');
$month = $_GET['month'] ?? '';
$status = $_GET['status'] ?? '';

// Aidatları getir
$dues = [];
$total_amount = 0;
$paid_amount = 0;
$unpaid_amount = 0;

try {
    $sql = "SELECT d.*, m.full_name, m.email, m.phone 
            FROM dues d 
            LEFT JOIN members m ON d.member_id = m.id 
            WHERE 1=1";
    $params = [];
    
    if (!empty($member_id)) {
        $sql .= " AND d.member_id = ?";
        $params[] = $member_id;
    }
    
    if (!empty($year)) {
        $sql .= " AND YEAR(d.due_date) = ?";
        $params[] = $year;
    }
    
    if (!empty($month)) {
        $sql .= " AND MONTH(d.due_date) = ?";
        $params[] = $month;
    }
    
    if (!empty($status) && $status != 'all') {
        $sql .= " AND d.status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY d.due_date DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $dues = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Toplam istatistikleri hesapla
    foreach ($dues as $due) {
        $total_amount += $due['amount'];
        if ($due['status'] == 'paid') {
            $paid_amount += $due['amount'];
        } else {
            $unpaid_amount += $due['amount'];
        }
    }
    
} catch(Exception $e) {
    $error = "Aidatlar yüklenirken hata oluştu: " . $e->getMessage();
}

// Üyeleri getir (dropdown için)
$members = [];
try {
    $stmt = $pdo->query("SELECT id, full_name FROM members WHERE status = 'active' ORDER BY full_name");
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Üyeler yüklenirken hata oluştu: " . $e->getMessage();
}

// Aidat ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_due'])) {
    try {
        $member_id = intval($_POST['member_id']);
        $amount = floatval($_POST['amount']);
        $due_date = $_POST['due_date'];
        $description = sanitizeInput($_POST['description']);
        
        $stmt = $pdo->prepare("INSERT INTO dues (member_id, amount, due_date, description) VALUES (?, ?, ?, ?)");
        if ($stmt->execute([$member_id, $amount, $due_date, $description])) {
            $success = "Aidat başarıyla eklendi!";
            echo "<script>window.location.href = 'dues_management.php?success=1&member_id=" . $member_id . "';</script>";
            exit;
        }
    } catch(Exception $e) {
        $error = "Aidat eklenirken hata oluştu: " . $e->getMessage();
    }
}

// Ödeme işlemi
if (isset($_GET['pay'])) {
    try {
        $id = intval($_GET['pay']);
        $stmt = $pdo->prepare("UPDATE dues SET status = 'paid', payment_date = NOW() WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "Aidat ödemesi kaydedildi!";
            echo "<script>window.location.href = 'dues_management.php?success=2&member_id=" . ($_GET['member_id'] ?? '') . "';</script>";
            exit;
        }
    } catch(Exception $e) {
        $error = "Ödeme işlemi sırasında hata oluştu: " . $e->getMessage();
    }
}

// Aidat silme
if (isset($_GET['delete'])) {
    try {
        $id = intval($_GET['delete']);
        $stmt = $pdo->prepare("DELETE FROM dues WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "Aidat başarıyla silindi!";
            echo "<script>window.location.href = 'dues_management.php?success=3&member_id=" . ($_GET['member_id'] ?? '') . "';</script>";
            exit;
        }
    } catch(Exception $e) {
        $error = "Aidat silinirken hata oluştu: " . $e->getMessage();
    }
}

// URL'den gelen success parametrelerini kontrol et
if (isset($_GET['success'])) {
    switch ($_GET['success']) {
        case '1': $success = "Aidat başarıyla eklendi!"; break;
        case '2': $success = "Aidat ödemesi kaydedildi!"; break;
        case '3': $success = "Aidat başarıyla silindi!"; break;
    }
}

$page_title = "Aidat Yönetimi - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-money-bill-wave"></i> Aidat Yönetimi</h1>
            <p>BEVAVE aidat kayıtlarını yönetin</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Yeni Aidat Ekle
            </button>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <!-- İstatistik Kartları -->
    <div class="row">
        <div class="col-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-primary"><?php echo number_format($total_amount, 2); ?> TL</h3>
                    <p class="text-muted">Toplam Aidat</p>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-success"><?php echo number_format($paid_amount, 2); ?> TL</h3>
                    <p class="text-muted">Tahsil Edilen</p>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-danger"><?php echo number_format($unpaid_amount, 2); ?> TL</h3>
                    <p class="text-muted">Tahsil Edilmeyen</p>
                </div>
            </div>
        </div>
        <div class="col-3">
            <div class="card">
                <div class="card-body text-center">
                    <h3 class="text-info"><?php echo count($dues); ?></h3>
                    <p class="text-muted">Toplam Kayıt</p>
                </div>
            </div>
        </div>
    </div>

    <!-- Filtreleme -->
    <div class="card">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-3">
                    <select name="member_id" class="form-control">
                        <option value="">Tüm Üyeler</option>
                        <?php foreach($members as $member): ?>
                            <option value="<?php echo $member['id']; ?>" <?php echo $member_id == $member['id'] ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($member['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="year" class="form-control">
                        <?php for($y = date('Y'); $y >= 2020; $y--): ?>
                            <option value="<?php echo $y; ?>" <?php echo $year == $y ? 'selected' : ''; ?>>
                                <?php echo $y; ?>
                            </option>
                        <?php endfor; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="month" class="form-control">
                        <option value="">Tüm Aylar</option>
                        <?php 
                        $months = [
                            1 => 'Ocak', 2 => 'Şubat', 3 => 'Mart', 4 => 'Nisan',
                            5 => 'Mayıs', 6 => 'Haziran', 7 => 'Temmuz', 8 => 'Ağustos',
                            9 => 'Eylül', 10 => 'Ekim', 11 => 'Kasım', 12 => 'Aralık'
                        ];
                        foreach($months as $num => $name): ?>
                            <option value="<?php echo $num; ?>" <?php echo $month == $num ? 'selected' : ''; ?>>
                                <?php echo $name; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <select name="status" class="form-control">
                        <option value="all">Tüm Durumlar</option>
                        <option value="paid" <?php echo $status == 'paid' ? 'selected' : ''; ?>>Ödenmiş</option>
                        <option value="unpaid" <?php echo $status == 'unpaid' ? 'selected' : ''; ?>>Ödenmemiş</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-filter"></i> Filtrele
                    </button>
                    <a href="dues_management.php" class="btn btn-secondary w-100 mt-2">
                        <i class="fas fa-redo"></i> Sıfırla
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Aidat Listesi -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Aidat Listesi (<?php echo count($dues); ?> kayıt)</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Üye</th>
                            <th>Miktar</th>
                            <th>Son Ödeme Tarihi</th>
                            <th>Ödeme Tarihi</th>
                            <th>Açıklama</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($dues)): ?>
                            <tr>
                                <td colspan="8" class="text-center text-muted">
                                    <i class="fas fa-info-circle"></i> Kayıtlı aidat bulunamadı
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($dues as $due): ?>
                            <tr>
                                <td><?php echo $due['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($due['full_name']); ?></strong>
                                    <?php if ($due['email']): ?>
                                        <br><small class="text-muted"><?php echo $due['email']; ?></small>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <span class="font-weight-bold text-success">
                                        <?php echo number_format($due['amount'], 2); ?> TL
                                    </span>
                                </td>
                                <td><?php echo date('d.m.Y', strtotime($due['due_date'])); ?></td>
                                <td>
                                    <?php if ($due['payment_date']): ?>
                                        <?php echo date('d.m.Y', strtotime($due['payment_date'])); ?>
                                    <?php else: ?>
                                        <span class="text-muted">-</span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo $due['description'] ?: '-'; ?></td>
                                <td>
                                    <span class="badge badge-<?php echo $due['status'] == 'paid' ? 'success' : 'danger'; ?>">
                                        <?php echo $due['status'] == 'paid' ? 'Ödendi' : 'Ödenmedi'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <?php if ($due['status'] == 'unpaid'): ?>
                                            <a href="?pay=<?php echo $due['id']; ?>&member_id=<?php echo $member_id; ?>" 
                                               class="btn btn-success btn-sm"
                                               onclick="return confirm('Bu aidatı ödenmiş olarak işaretlemek istediğinizden emin misiniz?')"
                                               title="Ödendi Olarak İşaretle">
                                                <i class="fas fa-check"></i>
                                            </a>
                                        <?php endif; ?>
                                        <a href="?delete=<?php echo $due['id']; ?>&member_id=<?php echo $member_id; ?>" 
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Bu aidatı silmek istediğinizden emin misiniz? Bu işlem geri alınamaz!')"
                                           title="Sil">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="dueModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Yeni Aidat Ekle</h3>
            <button type="button" class="close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST" id="dueForm">
            <div class="modal-body">
                <div class="form-group">
                    <label class="form-label">Üye *</label>
                    <select name="member_id" class="form-control" required>
                        <option value="">Üye Seçin</option>
                        <?php foreach($members as $member): ?>
                            <option value="<?php echo $member['id']; ?>" <?php echo ($member_id == $member['id']) ? 'selected' : ''; ?>>
                                <?php echo htmlspecialchars($member['full_name']); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="form-group">
                    <label class="form-label">Miktar (TL) *</label>
                    <input type="number" name="amount" class="form-control" step="0.01" min="0" required
                           placeholder="100.00">
                </div>
                <div class="form-group">
                    <label class="form-label">Son Ödeme Tarihi *</label>
                    <input type="date" name="due_date" class="form-control" required
                           value="<?php echo date('Y-m-d'); ?>">
                </div>
                <div class="form-group">
                    <label class="form-label">Açıklama</label>
                    <textarea name="description" class="form-control" rows="3" 
                              placeholder="Aidat açıklaması..."></textarea>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_due" class="btn btn-primary">
                    <i class="fas fa-save"></i> Kaydet
                </button>
            </div>
        </form>
    </div>
</div>

<script>
// Modal fonksiyonları
function openModal() {
    document.getElementById('dueModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('dueModal').style.display = 'none';
    document.getElementById('dueForm').reset();
}

// Modal dışına tıklayınca kapat
window.onclick = function(event) {
    const modal = document.getElementById('dueModal');
    if (event.target == modal) {
        closeModal();
    }
}

// Form gönderim butonunu yükleme durumuna getir
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('dueForm');
    if (form) {
        form.addEventListener('submit', function() {
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Kaydediliyor...';
        });
    }
    
    // Tarih kontrolü - geçmiş tarih olamaz
    const dateInput = document.querySelector('input[name="due_date"]');
    if (dateInput) {
        dateInput.min = new Date().toISOString().split('T')[0];
    }
});

// Sayfa yüklendiğinde URL'de member_id varsa modalı aç
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    const memberId = urlParams.get('member_id');
    
    <?php if (isset($_GET['member_id']) && !empty($_GET['member_id'])): ?>
        // Member ID varsa, modalı aç ve ilgili üyeyi seç
        setTimeout(() => {
            openModal();
        }, 500);
    <?php endif; ?>
});
</script>

<?php include '../../includes/footer.php'; ?>