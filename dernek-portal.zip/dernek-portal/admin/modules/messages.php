<?php
require_once '../../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit;
}

$success = '';
$error = '';

// Mesajları getir
$messages = [];
try {
    $stmt = $pdo->query("SELECT * FROM messages ORDER BY created_at DESC");
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Mesajlar yüklenirken hata oluştu: " . $e->getMessage();
}

// Mesaj durumu güncelleme
if (isset($_GET['mark_read'])) {
    try {
        $id = intval($_GET['mark_read']);
        $stmt = $pdo->prepare("UPDATE messages SET status = 'read' WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "Mesaj okundu olarak işaretlendi!";
        }
    } catch(Exception $e) {
        $error = "Mesaj güncellenirken hata oluştu: " . $e->getMessage();
    }
}

// Mesaj silme
if (isset($_GET['delete'])) {
    try {
        $id = intval($_GET['delete']);
        $stmt = $pdo->prepare("DELETE FROM messages WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "Mesaj başarıyla silindi!";
        }
    } catch(Exception $e) {
        $error = "Mesaj silinirken hata oluştu: " . $e->getMessage();
    }
}
?>
<!-- HTML yapısı diğer modüllerle benzer -->