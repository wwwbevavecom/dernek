<?php
require_once '../../includes/config.php';
require_once '../../includes/functions.php';

// Auth kontrolü
if (!defined('DEV_MODE') || DEV_MODE !== true) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../../login.php');
        exit;
    }
}

$page_title = "Üye Yönetimi - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-users"></i> Üye Yönetimi</h1>
            <p>BEVAVE üyelerini yönetin</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary">
                <i class="fas fa-plus"></i> Yeni Üye Ekle
            </button>
        </div>
    </div>

    <div class="card shadow">
        <div class="card-body">
            <p>Üye yönetimi içeriği buraya gelecek...</p>
        </div>
    </div>
</div>

<?php include '../../includes/footer.php'; ?>