<?php
require_once '../../../includes/config.php';

if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$success = '';
$error = '';

// Üye gruplarını getir
$groups = [];
try {
    $stmt = $pdo->query("SELECT * FROM member_groups ORDER BY created_at DESC");
    $groups = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    // Tablo yoksa oluştur
    $pdo->exec("CREATE TABLE IF NOT EXISTS member_groups (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        description TEXT,
        color VARCHAR(7) DEFAULT '#2c5aa0',
        permissions JSON,
        status ENUM('active', 'inactive') DEFAULT 'active',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )");
}

// Grup ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_group'])) {
    try {
        $name = sanitizeInput($_POST['name']);
        $description = sanitizeInput($_POST['description']);
        $color = sanitizeInput($_POST['color']);
        
        $stmt = $pdo->prepare("INSERT INTO member_groups (name, description, color) VALUES (?, ?, ?)");
        if ($stmt->execute([$name, $description, $color])) {
            $success = "Üye grubu başarıyla eklendi!";
        }
    } catch(Exception $e) {
        $error = "Grup eklenirken hata oluştu: " . $e->getMessage();
    }
}

// Grup silme
if (isset($_GET['delete'])) {
    try {
        $id = intval($_GET['delete']);
        $stmt = $pdo->prepare("DELETE FROM member_groups WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "Grup başarıyla silindi!";
        }
    } catch(Exception $e) {
        $error = "Grup silinirken hata oluştu: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Üye Grupları - BEVAVE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        /* Önceki CSS stilleri buraya gelecek */
        .color-preview {
            width: 20px;
            height: 20px;
            border-radius: 4px;
            display: inline-block;
            margin-right: 10px;
            border: 1px solid #ddd;
        }
    </style>
</head>
<body>
    <!-- Sidebar ve Header (önceki gibi) -->
    
    <div class="main-content">
        <div class="header">
            <div style="display: flex; align-items: center;">
                <button class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
                <h1>Üye Grupları</h1>
            </div>
        </div>
        
        <div class="content">
            <?php if ($success): ?>
                <div class="alert alert-success"><?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger"><?php echo $error; ?></div>
            <?php endif; ?>

            <div class="row">
                <div class="col-4">
                    <div class="card">
                        <div class="card-header">
                            <h3>Yeni Grup Ekle</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="form-group">
                                    <label>Grup Adı</label>
                                    <input type="text" name="name" class="form-control" required>
                                </div>
                                <div class="form-group">
                                    <label>Açıklama</label>
                                    <textarea name="description" class="form-control" rows="3"></textarea>
                                </div>
                                <div class="form-group">
                                    <label>Renk</label>
                                    <input type="color" name="color" class="form-control" value="#2c5aa0">
                                </div>
                                <button type="submit" name="add_group" class="btn btn-primary">Grup Ekle</button>
                            </form>
                        </div>
                    </div>
                </div>
                
                <div class="col-8">
                    <div class="card">
                        <div class="card-header">
                            <h3>Mevcut Gruplar</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Grup Adı</th>
                                            <th>Açıklama</th>
                                            <th>Renk</th>
                                            <th>Üye Sayısı</th>
                                            <th>İşlemler</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach($groups as $group): ?>
                                        <tr>
                                            <td><?php echo $group['id']; ?></td>
                                            <td><?php echo $group['name']; ?></td>
                                            <td><?php echo $group['description']; ?></td>
                                            <td>
                                                <span class="color-preview" style="background: <?php echo $group['color']; ?>"></span>
                                                <?php echo $group['color']; ?>
                                            </td>
                                            <td>0</td>
                                            <td>
                                                <a href="?delete=<?php echo $group['id']; ?>" class="btn btn-danger btn-sm"
                                                   onclick="return confirm('Bu grubu silmek istediğinizden emin misiniz?')">
                                                    <i class="fas fa-trash"></i> Sil
                                                </a>
                                            </td>
                                        </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>