<?php
require_once '../../../includes/config.php';

// Basit auth kontrolü
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

// ID kontrolü
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: member_management.php');
    exit;
}

$id = intval($_GET['id']);
$success = '';
$error = '';

// Üye bilgilerini getir
$member = [];
try {
    $stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
    $stmt->execute([$id]);
    $member = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$member) {
        $error = "Üye bulunamadı!";
    }
} catch(Exception $e) {
    $error = "Üye bilgileri yüklenirken hata oluştu: " . $e->getMessage();
}

// Üye güncelleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_member'])) {
    try {
        $full_name = sanitizeInput($_POST['full_name']);
        $tc_no = sanitizeInput($_POST['tc_no']);
        $email = sanitizeInput($_POST['email']);
        $phone = sanitizeInput($_POST['phone']);
        $address = sanitizeInput($_POST['address']);
        $membership_date = $_POST['membership_date'];
        $membership_type = sanitizeInput($_POST['membership_type']);
        $status = sanitizeInput($_POST['status']);
        
        // TC kimlik doğrulama
        if (!empty($tc_no) && strlen($tc_no) != 11) {
            $error = "TC kimlik numarası 11 haneli olmalıdır!";
        } else {
            $stmt = $pdo->prepare("UPDATE members SET 
                full_name = ?, 
                tc_no = ?, 
                email = ?, 
                phone = ?, 
                address = ?, 
                membership_date = ?, 
                membership_type = ?, 
                status = ? 
                WHERE id = ?");
                
            if ($stmt->execute([$full_name, $tc_no, $email, $phone, $address, $membership_date, $membership_type, $status, $id])) {
                $success = "Üye bilgileri başarıyla güncellendi!";
                // Güncel bilgileri tekrar getir
                $stmt = $pdo->prepare("SELECT * FROM members WHERE id = ?");
                $stmt->execute([$id]);
                $member = $stmt->fetch(PDO::FETCH_ASSOC);
            } else {
                $error = "Üye güncellenirken hata oluştu!";
            }
        }
    } catch(PDOException $e) {
        if ($e->getCode() == 23000) {
            $error = "Bu TC kimlik numarası veya e-posta başka bir üyede kullanılıyor!";
        } else {
            $error = "Üye güncellenirken hata oluştu: " . $e->getMessage();
        }
    }
}

$page_title = "Üye Düzenle - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-user-edit"></i> Üye Düzenle</h1>
            <p><?php echo htmlspecialchars($member['full_name'] ?? ''); ?> - Bilgilerini düzenleyin</p>
        </div>
        <div class="header-actions">
            <a href="member_management.php" class="btn btn-secondary">
                <i class="fas fa-arrow-left"></i> Listeye Dön
            </a>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger">
            <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
        </div>
    <?php endif; ?>

    <?php if (!$member && !$error): ?>
        <div class="alert alert-warning">
            <i class="fas fa-exclamation-circle"></i> Üye bulunamadı!
        </div>
    <?php endif; ?>

    <?php if ($member): ?>
    <div class="row">
        <div class="col-8">
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-user-cog"></i> Üye Bilgileri</h3>
                </div>
                <div class="card-body">
                    <form method="POST" id="editMemberForm">
                        <div class="form-group">
                            <label class="form-label">Ad Soyad *</label>
                            <input type="text" name="full_name" class="form-control" required 
                                   value="<?php echo htmlspecialchars($member['full_name']); ?>">
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">TC Kimlik No</label>
                                    <input type="text" name="tc_no" class="form-control" maxlength="11"
                                           value="<?php echo htmlspecialchars($member['tc_no'] ?? ''); ?>"
                                           oninput="this.value = this.value.replace(/[^0-9]/g, '')">
                                    <small class="form-text text-muted">11 haneli numara</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Üyelik Tipi</label>
                                    <select name="membership_type" class="form-control">
                                        <option value="standard" <?php echo ($member['membership_type'] ?? 'standard') == 'standard' ? 'selected' : ''; ?>>Standart</option>
                                        <option value="premium" <?php echo ($member['membership_type'] ?? '') == 'premium' ? 'selected' : ''; ?>>Premium</option>
                                        <option value="vip" <?php echo ($member['membership_type'] ?? '') == 'vip' ? 'selected' : ''; ?>>VIP</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">E-posta</label>
                                    <input type="email" name="email" class="form-control"
                                           value="<?php echo htmlspecialchars($member['email'] ?? ''); ?>">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Telefon</label>
                                    <input type="text" name="phone" class="form-control"
                                           value="<?php echo htmlspecialchars($member['phone'] ?? ''); ?>"
                                           oninput="this.value = this.value.replace(/[^0-9+]/g, '')">
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="form-label">Adres</label>
                            <textarea name="address" class="form-control" rows="3"><?php echo htmlspecialchars($member['address'] ?? ''); ?></textarea>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Üyelik Tarihi *</label>
                                    <input type="date" name="membership_date" class="form-control" required
                                           value="<?php echo $member['membership_date']; ?>">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Durum</label>
                                    <select name="status" class="form-control">
                                        <option value="active" <?php echo $member['status'] == 'active' ? 'selected' : ''; ?>>Aktif</option>
                                        <option value="passive" <?php echo $member['status'] == 'passive' ? 'selected' : ''; ?>>Pasif</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="form-group">
                            <button type="submit" name="update_member" class="btn btn-primary">
                                <i class="fas fa-save"></i> Bilgileri Güncelle
                            </button>
                            <a href="member_management.php" class="btn btn-secondary">
                                <i class="fas fa-times"></i> İptal
                            </a>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-4">
            <!-- Üye İstatistikleri -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-chart-bar"></i> Üye İstatistikleri</h3>
                </div>
                <div class="card-body">
                    <div class="member-stats">
                        <div class="stat-item">
                            <div class="stat-label">Üye ID</div>
                            <div class="stat-value">#<?php echo $member['id']; ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Kayıt Tarihi</div>
                            <div class="stat-value"><?php echo date('d.m.Y H:i', strtotime($member['created_at'])); ?></div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Son Güncelleme</div>
                            <div class="stat-value">
                                <?php 
                                if ($member['updated_at'] && $member['updated_at'] != $member['created_at']) {
                                    echo date('d.m.Y H:i', strtotime($member['updated_at']));
                                } else {
                                    echo 'Henüz güncellenmedi';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="stat-item">
                            <div class="stat-label">Üyelik Süresi</div>
                            <div class="stat-value">
                                <?php
                                $membership_date = new DateTime($member['membership_date']);
                                $today = new DateTime();
                                $interval = $today->diff($membership_date);
                                echo $interval->format('%y yıl %m ay %d gün');
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Hızlı İşlemler -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-bolt"></i> Hızlı İşlemler</h3>
                </div>
                <div class="card-body">
                    <div class="quick-actions">
                        <a href="?id=<?php echo $member['id']; ?>&action=send_welcome" class="btn btn-info btn-sm w-100 mb-2">
                            <i class="fas fa-envelope"></i> Hoşgeldin Maili Gönder
                        </a>
                        <a href="../financial/dues_management.php?member_id=<?php echo $member['id']; ?>" class="btn btn-warning btn-sm w-100 mb-2">
                            <i class="fas fa-money-bill-wave"></i> Aidat İşlemleri
                        </a>
                        <a href="member_management.php?delete=<?php echo $member['id']; ?>" 
                           class="btn btn-danger btn-sm w-100"
                           onclick="return confirm('Bu üyeyi silmek istediğinizden emin misiniz? Bu işlem geri alınamaz!')">
                            <i class="fas fa-trash"></i> Üyeyi Sil
                        </a>
                    </div>
                </div>
            </div>

            <!-- Durum Bilgisi -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-info-circle"></i> Durum</h3>
                </div>
                <div class="card-body">
                    <div class="status-info">
                        <div class="status-item">
                            <span class="status-label">Mevcut Durum:</span>
                            <span class="badge badge-<?php echo $member['status'] == 'active' ? 'success' : 'danger'; ?>">
                                <?php echo $member['status'] == 'active' ? 'Aktif' : 'Pasif'; ?>
                            </span>
                        </div>
                        <div class="status-item">
                            <span class="status-label">Üyelik Tipi:</span>
                            <span class="badge badge-info">
                                <?php 
                                $types = [
                                    'standard' => 'Standart',
                                    'premium' => 'Premium',
                                    'vip' => 'VIP'
                                ];
                                echo $types[$member['membership_type']] ?? 'Standart';
                                ?>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</div>

<style>
.member-stats {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.stat-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 10px 0;
    border-bottom: 1px solid #e2e8f0;
}

.stat-item:last-child {
    border-bottom: none;
}

.stat-label {
    font-weight: 500;
    color: #64748b;
}

.stat-value {
    font-weight: 600;
    color: #1e293b;
}

.quick-actions {
    display: flex;
    flex-direction: column;
    gap: 8px;
}

.status-info {
    display: flex;
    flex-direction: column;
    gap: 10px;
}

.status-item {
    display: flex;
    justify-content: space-between;
    align-items: center;
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // TC No validasyonu
    const tcInput = document.querySelector('input[name="tc_no"]');
    if (tcInput) {
        tcInput.addEventListener('blur', function() {
            const tc = this.value;
            if (tc && tc.length !== 11) {
                alert('TC kimlik numarası 11 haneli olmalıdır!');
                this.focus();
            }
        });
    }
    
    // Telefon formatı
    const phoneInput = document.querySelector('input[name="phone"]');
    if (phoneInput) {
        phoneInput.addEventListener('blur', function() {
            let phone = this.value.replace(/\D/g, '');
            if (phone.length === 10) {
                this.value = phone.replace(/(\d{3})(\d{3})(\d{2})(\d{2})/, '$1 $2 $3 $4');
            } else if (phone.length === 11) {
                this.value = phone.replace(/(\d{1})(\d{3})(\d{3})(\d{2})(\d{2})/, '+$1 $2 $3 $4 $5');
            }
        });
    }
    
    // Form gönderim butonunu yükleme durumuna getir
    const form = document.getElementById('editMemberForm');
    if (form) {
        form.addEventListener('submit', function() {
            const submitBtn = this.querySelector('button[type="submit"]');
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Güncelleniyor...';
        });
    }
    
    // Tarih kontrolü - gelecek tarih olamaz
    const dateInput = document.querySelector('input[name="membership_date"]');
    if (dateInput) {
        dateInput.max = new Date().toISOString().split('T')[0];
    }
});

// Sayfa yüklendiğinde başarı mesajı varsa, 3 saniye sonra kaybolsun
document.addEventListener('DOMContentLoaded', function() {
    const successAlert = document.querySelector('.alert-success');
    if (successAlert) {
        setTimeout(() => {
            successAlert.style.opacity = '0';
            setTimeout(() => {
                successAlert.remove();
            }, 300);
        }, 3000);
    }
});
</script>

<?php include '../../includes/footer.php'; ?>