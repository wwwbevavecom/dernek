<?php
define('ADMIN_PATH', true);
require_once '../../../includes/config.php';
require_once '../../../includes/auth.php';
require_once '../../includes/security.php';

if (!$auth->isLoggedIn() || !$auth->hasPermission('members_manage')) {
    header('Location: ../login.php');
    exit;
}

$success = $error = '';

// Üye listeleme
$members = [];
$search = $_GET['search'] ?? '';
$status = $_GET['status'] ?? '';

try {
    $sql = "SELECT * FROM members WHERE 1=1";
    $params = [];
    
    if (!empty($search)) {
        $sql .= " AND (full_name LIKE ? OR email LIKE ? OR tc_no LIKE ?)";
        $search_term = "%$search%";
        $params = array_merge($params, [$search_term, $search_term, $search_term]);
    }
    
    if (!empty($status) && $status != 'all') {
        $sql .= " AND status = ?";
        $params[] = $status;
    }
    
    $sql .= " ORDER BY created_at DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $members = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(Exception $e) {
    $error = "Üyeler yüklenirken hata oluştu: " . $e->getMessage();
}

// Üye ekleme
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_member']) && verifyCSRFToken($_POST['csrf_token'])) {
    try {
        $full_name = sanitizeInput($_POST['full_name']);
        $tc_no = sanitizeInput($_POST['tc_no']);
        $email = sanitizeInput($_POST['email']);
        $phone = sanitizeInput($_POST['phone']);
        $address = sanitizeInput($_POST['address']);
        $membership_date = $_POST['membership_date'];
        $membership_type = sanitizeInput($_POST['membership_type']);
        
        // TC kimlik doğrulama
        if (!empty($tc_no) && strlen($tc_no) != 11) {
            $error = "TC kimlik numarası 11 haneli olmalıdır!";
        } else {
            $stmt = $pdo->prepare("INSERT INTO members (full_name, tc_no, email, phone, address, membership_date, membership_type) VALUES (?, ?, ?, ?, ?, ?, ?)");
            if ($stmt->execute([$full_name, $tc_no, $email, $phone, $address, $membership_date, $membership_type])) {
                $success = "Üye başarıyla eklendi!";
            } else {
                $error = "Üye eklenirken hata oluştu!";
            }
        }
    } catch(PDOException $e) {
        if ($e->getCode() == 23000) {
            $error = "Bu TC kimlik numarası veya e-posta zaten kayıtlı!";
        } else {
            $error = "Üye eklenirken hata oluştu: " . $e->getMessage();
        }
    }
}

// Üye silme
if (isset($_GET['delete']) && verifyCSRFToken($_GET['csrf_token'] ?? '')) {
    try {
        $id = intval($_GET['delete']);
        $stmt = $pdo->prepare("UPDATE members SET status = 'deleted' WHERE id = ?");
        if ($stmt->execute([$id])) {
            $success = "Üye başarıyla silindi!";
        } else {
            $error = "Üye silinirken hata oluştu!";
        }
    } catch(Exception $e) {
        $error = "Üye silinirken hata oluştu: " . $e->getMessage();
    }
}

$page_title = "Üye Yönetimi - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-users"></i> Üye Yönetimi</h1>
            <p>BEVAVE üye kayıtlarını yönetin</p>
        </div>
        <div class="header-actions">
            <button class="btn btn-primary" onclick="openModal()">
                <i class="fas fa-plus"></i> Yeni Üye Ekle
            </button>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success"><?php echo $success; ?></div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger"><?php echo $error; ?></div>
    <?php endif; ?>

    <!-- Filtreleme -->
    <div class="card">
        <div class="card-body">
            <form method="GET" class="row g-3">
                <div class="col-md-4">
                    <input type="text" name="search" class="form-control" placeholder="İsim, TC No veya E-posta ara..." 
                           value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-3">
                    <select name="status" class="form-control">
                        <option value="all">Tüm Durumlar</option>
                        <option value="active" <?php echo $status == 'active' ? 'selected' : ''; ?>>Aktif</option>
                        <option value="passive" <?php echo $status == 'passive' ? 'selected' : ''; ?>>Pasif</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn btn-primary w-100">
                        <i class="fas fa-search"></i> Ara
                    </button>
                </div>
                <div class="col-md-3">
                    <a href="member_management.php" class="btn btn-secondary w-100">
                        <i class="fas fa-redo"></i> Sıfırla
                    </a>
                </div>
            </form>
        </div>
    </div>

    <!-- Üye Listesi -->
    <div class="card">
        <div class="card-header">
            <h3><i class="fas fa-list"></i> Üye Listesi (<?php echo count($members); ?> kayıt)</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-striped table-hover">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Ad Soyad</th>
                            <th>TC No</th>
                            <th>E-posta</th>
                            <th>Telefon</th>
                            <th>Üyelik Tarihi</th>
                            <th>Tip</th>
                            <th>Durum</th>
                            <th>İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($members)): ?>
                            <tr>
                                <td colspan="9" class="text-center text-muted">
                                    <i class="fas fa-info-circle"></i> Kayıtlı üye bulunamadı
                                </td>
                            </tr>
                        <?php else: ?>
                            <?php foreach($members as $member): ?>
                            <tr>
                                <td><?php echo $member['id']; ?></td>
                                <td>
                                    <strong><?php echo htmlspecialchars($member['full_name']); ?></strong>
                                </td>
                                <td><?php echo $member['tc_no']; ?></td>
                                <td><?php echo $member['email']; ?></td>
                                <td><?php echo $member['phone']; ?></td>
                                <td><?php echo date('d.m.Y', strtotime($member['membership_date'])); ?></td>
                                <td>
                                    <span class="badge badge-info"><?php echo $member['membership_type'] ?? 'Standart'; ?></span>
                                </td>
                                <td>
                                    <span class="badge badge-<?php echo $member['status'] == 'active' ? 'success' : 'danger'; ?>">
                                        <?php echo $member['status'] == 'active' ? 'Aktif' : 'Pasif'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="btn-group">
                                        <a href="member_edit.php?id=<?php echo $member['id']; ?>" class="btn btn-sm btn-warning">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="?delete=<?php echo $member['id']; ?>&csrf_token=<?php echo $_SESSION['csrf_token']; ?>" 
                                           class="btn btn-sm btn-danger" 
                                           onclick="return confirm('Bu üyeyi silmek istediğinizden emin misiniz?')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal -->
<div id="memberModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3>Yeni Üye Ekle</h3>
            <button type="button" class="close" onclick="closeModal()">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label>Ad Soyad *</label>
                    <input type="text" name="full_name" class="form-control" required>
                </div>
                <div class="row">
                    <div class="col-6">
                        <div class="form-group">
                            <label>TC Kimlik No</label>
                            <input type="text" name="tc_no" class="form-control" maxlength="11">
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="form-group">
                            <label>Üyelik Tipi</label>
                            <select name="membership_type" class="form-control">
                                <option value="standard">Standart</option>
                                <option value="premium">Premium</option>
                                <option value="vip">VIP</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label>E-posta</label>
                    <input type="email" name="email" class="form-control">
                </div>
                <div class="form-group">
                    <label>Telefon</label>
                    <input type="text" name="phone" class="form-control">
                </div>
                <div class="form-group">
                    <label>Adres</label>
                    <textarea name="address" class="form-control" rows="3"></textarea>
                </div>
                <div class="form-group">
                    <label>Üyelik Tarihi *</label>
                    <input type="date" name="membership_date" class="form-control" required>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="closeModal()">İptal</button>
                <button type="submit" name="add_member" class="btn btn-primary">Kaydet</button>
            </div>
        </form>
    </div>
</div>

<script>
function openModal() {
    document.getElementById('memberModal').style.display = 'block';
}

function closeModal() {
    document.getElementById('memberModal').style.display = 'none';
}

window.onclick = function(event) {
    const modal = document.getElementById('memberModal');
    if (event.target == modal) {
        closeModal();
    }
}
</script>

<?php include '../../includes/footer.php'; ?>