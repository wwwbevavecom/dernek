<?php
require_once '../../../admin/includes/config.php';

// Geliştirme modunda değilse auth kontrolü
if (!defined('DEV_MODE') || DEV_MODE !== true) {
    if (!isset($_SESSION['user_id'])) {
        header('Location: ../../login.php');
        exit;
    }
}

$success = '';
$error = '';

// Ayarları kaydetme işlemi
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['save_settings'])) {
    try {
        // Burada ayarları veritabanına kaydedeceğiz
        $site_title = sanitizeInput($_POST['site_title']);
        $site_description = sanitizeInput($_POST['site_description']);
        $admin_email = sanitizeInput($_POST['admin_email']);
        $phone_number = sanitizeInput($_POST['phone_number']);
        $address = sanitizeInput($_POST['address']);
        
        // Geçici olarak session'a kaydedelim (ileride veritabanına kaydedeceğiz)
        $_SESSION['site_settings'] = [
            'site_title' => $site_title,
            'site_description' => $site_description,
            'admin_email' => $admin_email,
            'phone_number' => $phone_number,
            'address' => $address
        ];
        
        $success = "Ayarlar başarıyla kaydedildi!";
        
    } catch(Exception $e) {
        $error = "Ayarlar kaydedilirken hata oluştu: " . $e->getMessage();
    }
}

$page_title = "Genel Ayarlar - BEVAVE";
include '../../includes/header.php';
?>

<div class="content">
    <div class="content-header">
        <div class="header-title">
            <h1><i class="fas fa-cogs"></i> Genel Ayarlar</h1>
            <p>BEVAVE sistem genel ayarlarını yönetin</p>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <i class="fas fa-check-circle"></i> <?php echo $success; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>
    
    <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show" role="alert">
            <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-md-8">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Site Ayarları</h6>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="form-group">
                            <label for="site_title">Site Başlığı</label>
                            <input type="text" class="form-control" id="site_title" name="site_title" 
                                   value="<?php echo $_SESSION['site_settings']['site_title'] ?? 'BEVAVE Dernek Yönetim Sistemi'; ?>" 
                                   required>
                            <small class="form-text text-muted">Sitenizin ana başlığı</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="site_description">Site Açıklaması</label>
                            <textarea class="form-control" id="site_description" name="site_description" 
                                      rows="3"><?php echo $_SESSION['site_settings']['site_description'] ?? 'BEVAVE Derneği resmi yönetim sistemi'; ?></textarea>
                            <small class="form-text text-muted">Sitenizin kısa açıklaması</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="admin_email">Yönetici Email</label>
                            <input type="email" class="form-control" id="admin_email" name="admin_email" 
                                   value="<?php echo $_SESSION['site_settings']['admin_email'] ?? 'admin@bevave.com'; ?>" 
                                   required>
                            <small class="form-text text-muted">Sistem bildirimlerinin gönderileceği email</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone_number">Telefon Numarası</label>
                            <input type="text" class="form-control" id="phone_number" name="phone_number" 
                                   value="<?php echo $_SESSION['site_settings']['phone_number'] ?? '+90 (555) 123 4567'; ?>">
                            <small class="form-text text-muted">İletişim için telefon numarası</small>
                        </div>
                        
                        <div class="form-group">
                            <label for="address">Adres</label>
                            <textarea class="form-control" id="address" name="address" 
                                      rows="2"><?php echo $_SESSION['site_settings']['address'] ?? 'İstanbul, Türkiye'; ?></textarea>
                            <small class="form-text text-muted">Dernek adresi</small>
                        </div>
                        
                        <button type="submit" name="save_settings" class="btn btn-primary">
                            <i class="fas fa-save"></i> Ayarları Kaydet
                        </button>
                    </form>
                </div>
            </div>
        </div>
        
        <div class="col-md-4">
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Sistem Bilgileri</h6>
                </div>
                <div class="card-body">
                    <div class="system-info">
                        <div class="info-item">
                            <strong>PHP Sürümü:</strong> 
                            <span class="float-right"><?php echo PHP_VERSION; ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Veritabanı:</strong> 
                            <span class="float-right">MySQL</span>
                        </div>
                        <div class="info-item">
                            <strong>Sunucu Yazılımı:</strong> 
                            <span class="float-right"><?php echo $_SERVER['SERVER_SOFTWARE'] ?? 'Bilinmiyor'; ?></span>
                        </div>
                        <div class="info-item">
                            <strong>Son Güncelleme:</strong> 
                            <span class="float-right"><?php echo date('d/m/Y H:i'); ?></span>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card shadow">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Hızlı İşlemler</h6>
                </div>
                <div class="card-body">
                    <div class="list-group">
                        <a href="../members/member_management.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-users mr-2"></i>Üye Yönetimi
                        </a>
                        <a href="../financial/donation_management.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-donate mr-2"></i>Bağış Yönetimi
                        </a>
                        <a href="../content/news_management.php" class="list-group-item list-group-item-action">
                            <i class="fas fa-newspaper mr-2"></i>Haber Yönetimi
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.system-info .info-item {
    padding: 10px 0;
    border-bottom: 1px solid #e3e6f0;
}

.system-info .info-item:last-child {
    border-bottom: none;
}

.list-group-item {
    border: none;
    padding: 12px 15px;
}

.list-group-item:hover {
    background-color: #f8f9fa;
}
</style>

<?php include '../../includes/footer.php'; ?>