<?php
require_once '../../../includes/config.php';

// Basit auth kontrolü
if (!isset($_SESSION['user_id'])) {
    header('Location: ../../login.php');
    exit;
}

$success = '';
$error = '';

// Mail ayarlarını getir
$mail_settings = [];
try {
    $stmt = $pdo->query("SELECT * FROM settings WHERE setting_key LIKE 'mail_%'");
    $mail_data = $stmt->fetchAll(PDO::FETCH_ASSOC);
    foreach ($mail_data as $setting) {
        $mail_settings[$setting['setting_key']] = $setting['setting_value'];
    }
} catch(Exception $e) {
    $error = "Mail ayarları yüklenirken hata oluştu: " . $e->getMessage();
}

// Mail ayarlarını güncelle
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        $mail_settings_to_update = [
            'mail_host' => $_POST['mail_host'] ?? '',
            'mail_port' => $_POST['mail_port'] ?? '',
            'mail_username' => $_POST['mail_username'] ?? '',
            'mail_password' => $_POST['mail_password'] ?? '',
            'mail_from_email' => $_POST['mail_from_email'] ?? '',
            'mail_from_name' => $_POST['mail_from_name'] ?? '',
            'mail_encryption' => $_POST['mail_encryption'] ?? '',
            'mail_smtp_auth' => $_POST['mail_smtp_auth'] ?? '1'
        ];
        
        foreach ($mail_settings_to_update as $key => $value) {
            $stmt = $pdo->prepare("INSERT INTO settings (setting_key, setting_value) VALUES (?, ?) 
                                  ON DUPLICATE KEY UPDATE setting_value = ?");
            $stmt->execute([$key, $value, $value]);
        }
        
        $success = "Mail ayarları başarıyla güncellendi!";
    } catch(Exception $e) {
        $error = "Mail ayarları güncellenirken hata oluştu: " . $e->getMessage();
    }
}

// Test mail gönderimi
if (isset($_POST['test_mail'])) {
    $test_email = sanitizeInput($_POST['test_email']);
    $test_subject = "BEVAVE Test Maili";
    $test_message = "Bu bir test mailidir. Eğer bu mesajı okuyorsanız, mail ayarlarınız doğru çalışıyor demektir.\n\nGönderim Zamanı: " . date('d.m.Y H:i:s');
    
    // Basit mail fonksiyonu (gerçek uygulamada PHPMailer kullanılmalı)
    $headers = "From: " . ($mail_settings['mail_from_email'] ?? 'noreply@bevave.com') . "\r\n";
    $headers .= "Reply-To: " . ($mail_settings['mail_from_email'] ?? 'noreply@bevave.com') . "\r\n";
    $headers .= "Content-Type: text/plain; charset=utf-8\r\n";
    
    if (mail($test_email, $test_subject, $test_message, $headers)) {
        $success = "Test maili başarıyla gönderildi!";
    } else {
        $error = "Test maili gönderilemedi. Lütfen mail ayarlarını kontrol edin.";
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mail Ayarları - BEVAVE</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        :root {
            --primary: #2c5aa0;
            --secondary: #1e3a8a;
            --accent: #f59e0b;
            --sidebar-width: 280px;
        }
        
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
        body { 
            background: #f5f7fa; 
            color: #333;
            display: flex;
            min-height: 100vh;
        }
        
        /* Sidebar Styles - Öncekiyle aynı */
        .sidebar {
            width: var(--sidebar-width);
            background: linear-gradient(180deg, var(--primary) 0%, var(--secondary) 100%);
            color: white;
            height: 100vh;
            position: fixed;
            overflow-y: auto;
            transition: all 0.3s;
            z-index: 1000;
        }
        
        .sidebar-header {
            padding: 25px 20px;
            background: rgba(0, 0, 0, 0.1);
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .brand-logo {
            font-size: 2.5rem;
            margin-bottom: 10px;
            color: var(--accent);
        }
        
        .brand-title {
            font-size: 1.4rem;
            font-weight: 700;
            margin-bottom: 5px;
        }
        
        .brand-subtitle {
            font-size: 0.8rem;
            opacity: 0.8;
        }
        
        .sidebar-menu {
            padding: 20px 0;
        }
        
        .menu-section {
            margin-bottom: 20px;
        }
        
        .menu-title {
            padding: 10px 20px;
            font-size: 0.8rem;
            text-transform: uppercase;
            letter-spacing: 1px;
            opacity: 0.7;
            font-weight: 600;
        }
        
        .menu-items {
            list-style: none;
        }
        
        .menu-item {
            position: relative;
        }
        
        .menu-link {
            display: flex;
            align-items: center;
            padding: 12px 20px;
            color: rgba(255, 255, 255, 0.9);
            text-decoration: none;
            transition: all 0.3s;
            border-left: 3px solid transparent;
        }
        
        .menu-link:hover, .menu-link.active {
            background: rgba(255, 255, 255, 0.1);
            color: white;
            border-left: 3px solid var(--accent);
        }
        
        .menu-icon {
            width: 20px;
            text-align: center;
            margin-right: 12px;
            font-size: 1.1rem;
        }
        
        .menu-text {
            flex: 1;
        }
        
        /* Main Content */
        .main-content {
            flex: 1;
            margin-left: var(--sidebar-width);
            transition: all 0.3s;
        }
        
        .header {
            background: white;
            padding: 0 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            display: flex;
            align-items: center;
            justify-content: space-between;
            height: 70px;
        }
        
        .header h1 { color: var(--primary); }
        
        .user-info { 
            display: flex; 
            align-items: center; 
            gap: 15px; 
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--primary);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: bold;
        }
        
        .content { padding: 30px; }
        
        .card {
            background: white;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 25px;
            overflow: hidden;
        }
        
        .card-header {
            padding: 20px 25px;
            background: white;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .card-header h3 {
            margin: 0;
            font-size: 1.2rem;
            color: #1e293b;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .card-body {
            padding: 25px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: #1e293b;
        }
        
        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e2e8f0;
            border-radius: 8px;
            font-size: 0.95rem;
            transition: all 0.3s;
        }
        
        .form-control:focus {
            border-color: var(--primary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(44, 90, 160, 0.1);
        }
        
        .btn {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            padding: 12px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 500;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s;
            font-size: 0.9rem;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-success {
            background: #10b981;
            color: white;
        }
        
        .btn-primary:hover, .btn-success:hover {
            transform: translateY(-2px);
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #d1fae5;
            color: #065f46;
            border: 1px solid #a7f3d0;
        }
        
        .alert-danger {
            background: #fee2e2;
            color: #991b1b;
            border: 1px solid #fecaca;
        }
        
        .toggle-sidebar {
            display: none;
            background: none;
            border: none;
            font-size: 1.3rem;
            color: var(--primary);
            cursor: pointer;
            margin-right: 20px;
        }
        
        .row {
            display: flex;
            flex-wrap: wrap;
            margin: 0 -15px;
        }
        
        .col-6 { flex: 0 0 50%; max-width: 50%; }
        .col-12 { flex: 0 0 100%; max-width: 100%; }
        
        [class*="col-"] {
            padding: 0 15px;
        }
        
        .test-mail-section {
            background: #f8fafc;
            border-radius: 8px;
            padding: 20px;
            margin-top: 30px;
            border-left: 4px solid var(--accent);
        }
        
        /* Responsive */
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            
            .sidebar.active {
                transform: translateX(0);
            }
            
            .main-content {
                margin-left: 0;
            }
            
            .toggle-sidebar {
                display: block;
            }
            
            .col-6 {
                flex: 0 0 100%;
                max-width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="sidebar-header">
            <div class="brand-logo">
                <i class="fas fa-shield-alt"></i>
            </div>
            <div class="brand-title">BEVAVE</div>
            <div class="brand-subtitle">Dernek Yönetim Sistemi</div>
        </div>
        
        <nav class="sidebar-menu">
            <!-- Ana Menü -->
            <div class="menu-section">
                <div class="menu-title">Ana Menü</div>
                <ul class="menu-items">
                    <li class="menu-item">
                        <a href="../../index.php" class="menu-link">
                            <i class="menu-icon fas fa-home"></i>
                            <span class="menu-text">Dashboard</span>
                        </a>
                    </li>
                </ul>
            </div>
            
            <!-- Site Yönetimi -->
            <div class="menu-section">
                <div class="menu-title">Site Yönetimi</div>
                <ul class="menu-items">
                    <li class="menu-item">
                        <a href="general_settings.php" class="menu-link">
                            <i class="menu-icon fas fa-cogs"></i>
                            <span class="menu-text">Genel Ayarlar</span>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="social_media.php" class="menu-link">
                            <i class="menu-icon fas fa-share-alt"></i>
                            <span class="menu-text">Sosyal Medya</span>
                        </a>
                    </li>
                    <li class="menu-item">
                        <a href="mail_settings.php" class="menu-link active">
                            <i class="menu-icon fas fa-envelope"></i>
                            <span class="menu-text">Mail Ayarları</span>
                        </a>
                    </li>
                </ul>
            </div>
            
            <!-- Diğer menüler... -->
        </nav>
    </div>
    
    <!-- Main Content -->
    <div class="main-content">
        <div class="header">
            <div style="display: flex; align-items: center;">
                <button class="toggle-sidebar">
                    <i class="fas fa-bars"></i>
                </button>
                <h1>Mail Ayarları</h1>
            </div>
            
            <div class="user-info">
                <div class="user-avatar">
                    <?php 
                    $initials = '';
                    if (!empty($_SESSION['full_name'])) {
                        $name_parts = explode(' ', $_SESSION['full_name']);
                        foreach ($name_parts as $part) {
                            $initials .= strtoupper(substr($part, 0, 1));
                            if (strlen($initials) >= 2) break;
                        }
                    }
                    echo $initials ?: 'AD';
                    ?>
                </div>
                <span><?php echo $_SESSION['full_name']; ?></span>
                <a href="../../login.php?logout=1" class="btn" style="background: var(--accent); color: white;">
                    <i class="fas fa-sign-out-alt"></i> Çıkış
                </a>
            </div>
        </div>
        
        <div class="content">
            <?php if ($success): ?>
                <div class="alert alert-success">
                    <i class="fas fa-check-circle"></i> <?php echo $success; ?>
                </div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-danger">
                    <i class="fas fa-exclamation-triangle"></i> <?php echo $error; ?>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-server"></i> SMTP Ayarları</h3>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">SMTP Sunucusu</label>
                                    <input type="text" name="mail_host" class="form-control" 
                                           value="<?php echo $mail_settings['mail_host'] ?? 'smtp.gmail.com'; ?>" 
                                           placeholder="smtp.gmail.com">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">SMTP Port</label>
                                    <input type="number" name="mail_port" class="form-control" 
                                           value="<?php echo $mail_settings['mail_port'] ?? '587'; ?>" 
                                           placeholder="587">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Kullanıcı Adı</label>
                                    <input type="text" name="mail_username" class="form-control" 
                                           value="<?php echo $mail_settings['mail_username'] ?? ''; ?>" 
                                           placeholder="email@adresiniz.com">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Şifre</label>
                                    <input type="password" name="mail_password" class="form-control" 
                                           value="<?php echo $mail_settings['mail_password'] ?? ''; ?>" 
                                           placeholder="Mail şifreniz">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Gönderen E-posta</label>
                                    <input type="email" name="mail_from_email" class="form-control" 
                                           value="<?php echo $mail_settings['mail_from_email'] ?? ''; ?>" 
                                           placeholder="noreply@dernekadiniz.com">
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Gönderen İsim</label>
                                    <input type="text" name="mail_from_name" class="form-control" 
                                           value="<?php echo $mail_settings['mail_from_name'] ?? 'BEVAVE Dernek'; ?>" 
                                           placeholder="BEVAVE Dernek">
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">Şifreleme</label>
                                    <select name="mail_encryption" class="form-control">
                                        <option value="">Seçiniz</option>
                                        <option value="ssl" <?php echo ($mail_settings['mail_encryption'] ?? '') == 'ssl' ? 'selected' : ''; ?>>SSL</option>
                                        <option value="tls" <?php echo ($mail_settings['mail_encryption'] ?? '') == 'tls' ? 'selected' : ''; ?>>TLS</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="form-group">
                                    <label class="form-label">SMTP Kimlik Doğrulama</label>
                                    <select name="mail_smtp_auth" class="form-control">
                                        <option value="1" <?php echo ($mail_settings['mail_smtp_auth'] ?? '1') == '1' ? 'selected' : ''; ?>>Açık</option>
                                        <option value="0" <?php echo ($mail_settings['mail_smtp_auth'] ?? '1') == '0' ? 'selected' : ''; ?>>Kapalı</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save"></i> Mail Ayarlarını Kaydet
                        </button>
                    </form>
                </div>
            </div>

            <!-- Test Mail Bölümü -->
            <div class="test-mail-section">
                <h4 style="margin-bottom: 15px; color: #1e293b;">
                    <i class="fas fa-paper-plane"></i> Test Maili Gönder
                </h4>
                <form method="POST">
                    <div class="row">
                        <div class="col-6">
                            <div class="form-group">
                                <label class="form-label">Test E-posta Adresi</label>
                                <input type="email" name="test_email" class="form-control" 
                                       placeholder="test@ornek.com" required>
                            </div>
                        </div>
                        <div class="col-6">
                            <div class="form-group" style="display: flex; align-items: end; height: 100%;">
                                <button type="submit" name="test_mail" class="btn btn-success">
                                    <i class="fas fa-paper-plane"></i> Test Maili Gönder
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Bilgi Kartı -->
            <div class="card">
                <div class="card-header">
                    <h3><i class="fas fa-info-circle"></i> SMTP Bilgileri</h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <h5>Gmail Ayarları:</h5>
                            <ul style="color: #64748b; line-height: 1.6;">
                                <li>SMTP Sunucusu: smtp.gmail.com</li>
                                <li>Port: 587 (TLS) veya 465 (SSL)</li>
                                <li>Kullanıcı Adı: Gmail adresiniz</li>
                                <li>Şifre: Uygulama şifreniz</li>
                            </ul>
                        </div>
                        <div class="col-6">
                            <h5>Outlook/Hotmail Ayarları:</h5>
                            <ul style="color: #64748b; line-height: 1.6;">
                                <li>SMTP Sunucusu: smtp-mail.outlook.com</li>
                                <li>Port: 587</li>
                                <li>Şifreleme: TLS</li>
                                <li>Kullanıcı Adı: Outlook adresiniz</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Toggle sidebar for mobile
        document.querySelector('.toggle-sidebar').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });
        
        // Close sidebar when clicking on menu items on mobile
        document.querySelectorAll('.menu-link').forEach(item => {
            item.addEventListener('click', function() {
                if (window.innerWidth <= 768) {
                    document.querySelector('.sidebar').classList.remove('active');
                }
            });
        });
    </script>
</body>
</html>